<!DOCTYPE html>
<html lang="es">

<head>
  <link rel="shoortcut icon" type="image/x-icon" href="img/Logo.jpg">

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="stylesheet" href="css/estilos.css">
  <link rel="stylesheet" href="css/footer.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/all.css">
  <link rel="stylesheet" href="css/redes_sociales.css">
  <link href="https://fonts.googleapis.com/css?family=Titillium+Web:400,600" rel="stylesheet">
  <title>AYÚDAME EN</title>
  <style>



#hero{
  background-size: cover;
  padding-top: 120px;
  padding-bottom: 70px;
  min-height: 10px;
  background-image: url(../AYUDAME_EN/img/contactenos/3.jpg)!important;
  
}


  </style>

</head>

<body>



  <!-- EMPIEZA EL CONTENIDO COMPLETO DE LA PAGINA PRINCIPAL -->

  <!-- style="background: #26292c!important;" -->
  <!--EMPIEZA EL MENU-->
  <nav  class="navbar navbar-expand-xl bg-dark navbar-dark fixed-top">
    <a href="index.php" class="zoom navbar-brand "><img src="img/logo1.png" width="110" height="89"></a>

    <button class="navbar-toggler " type="button" data-toggle="collapse" data-target="#uno">
      <span class="navbar-toggler-icon"></span>
    </button>


    <div class="collapse navbar-collapse" id="uno">

      <ul class="navbar-nav mr-auto  ">

        <li  class="nav-item dropdown mr-2">
          <a href="" class="su nav-link dropdown-toggle mr-1" data-toggle="dropdown">
            <i class="fas fa-baby mr-2"></i>Primaria </a>
          <div  class="dropdown-menu">
            <a href="preescolar.html" class="dropdown-item">Preescolar<i class="fas fa-apple-alt ml-2"></i></a>
            <a href="1.html" class="dropdown-item">Primero 1º</a>
            <a href="2.html" class="dropdown-item">Segundo 2º</a>
            <a href="3.html" class="dropdown-item">Tercero 3º</a>
            <a href="4.html" class="dropdown-item">Cuarto 4º</a>
            <a href="5.html" class="dropdown-item">Quinto 5º</a>
          </div>
        </li>
        <li class="nav-item dropdown mr-2">
          <a href="" class="su nav-link dropdown-toggle mr-1" data-toggle="dropdown">
            <i class="fas fa-child mr-2"></i>Secundaria </a>

          <div class="dropdown-menu">
            <a href="6.html" class="dropdown-item">Sexto 6º</a>
            <a href="7.html" class="dropdown-item">Séptimo 7º</a>
            <a href="8.html" class="dropdown-item">Octavo 8º</a>
            <a href="9.html" class="dropdown-item">Noveno 9º</a>
            <a href="10.html" class="dropdown-item">Décimo 10º</a>
            <a href="11.html" class="dropdown-item">Undécimo 11º</a>
          </div>

        </li>

        <li class="nav-item dropdown mr-2">
          <a href="#" class="su nav-link dropdown-toggle mr-1" data-toggle="dropdown">

            <i class="fas fa-graduation-cap mr-2"></i>Medias técnicas </a>
          <div class="dropdown-menu">
            <a href="software.html" class="dropdown-item"> Desarrollo de Software<i style="font-size: 23px;" class="fas fa-laptop-code ml-2"></i></a>
            <a href="preprensa.html" class="dropdown-item">Preprensa<i style="font-size: 23px;" class="fas fa-paint-brush ml-2"></i></a>
            <a href="recursoshumano.html" class="dropdown-item">Recursos humanos<i style="font-size: 23px;" class="fas fa-user-tie ml-2"></i></a>
          </div>
        </li>
      
    
        <li class="nav-item">
          <a href="" class="su nav-link "><i  class="far fa-comments mr-2"></i>Foro</a>
      </li>

      </ul>

      <!-- COMIENZA FORMULARIO -->
      <div class="d-flex flex-row justify-content">
        <a href="Iniciar_sesion.php" class="Q btn btn-lg btn-primary mr-3 n"><i class="fas fa-user"></i>
          Iniciar Sesión </a>
        <a style="margin-left:-0px;" href="Registro.php" class="Q btn btn-lg btn-primary n"><i
            class="fas fa-sign-in-alt mr-1"></i>Regístrate</a>
        <!-- TERMINA FORMULARIO -->

      </div>
    </div>

  </nav>

 
  <!--TERMINA EL MENU-->
 

  <section id="hero"  style="border-bottom: 47px solid #121212; ">
   
    <div class="container">
      <div style="color: #fff; " class="content-center">
        <h1 style="font-size: 54px; font-weight: bold; font-family:  'Titillium Web', sans-serif;  " class="mt-5">
          ¡Bienvenido a Ayúdame en! <i class=" far fa-laugh-wink"></i></h1>
        <p style="font-size: 23px;  font-weight: 500;"> Aprende con Ayúdame en primaria ,Secundaria y tambien aprende
          con Ayúdame en las siguientes medias tecnicas que son: desarrollado de software,preprensa y recursos humanos.
          que esperas empieza a aprender con Ayúdame en. </p>

        <a href="empieza_a_aprender.html" class="KO btn btn-success mt-4">¡Empiece a aprender ahora! <i
            class="fas fa-arrow-alt-circle-right"></i></a>



      </div>
   
    </div>
  
  </section>




  <br>
  <br><br>



  

  <!-- EMPIEZA QUE ES AYUDAME EN -->
  <div  class="container">


    <div class="row">
      <div class="xo  col-md-12 col-xl-8 col-lg-12 mt-1">
        <h1 class="text-center"><b>¿Qué es ayúdame en? <i class="ml-2 far fa-question-circle"></i></b></h1>

        <p>Ayúdame en es un sistema web en etapa de desarrollo el cual permite al usuario la posibilidad de resolver
          dudas mediante formatos de aprendizaje o de forma presencial acerca de temas educativos dándonos posibilidades
          de encontrar contenido productivo y adaptado a cada una de las necesidades del individuo es adaptable a
          celulares, tables y computadores <br> <br></p>
      </div>
      <div class="xo text-center col-md-12 col-xl-4 col-lg-12 mt-1">
        <div class="inner">
          <img style="border-radius: 23px; width: 400px; height: 338px;" src="img/logo_deayudameen.jpg"
            class="img-fluid">
        </div>
      </div>

    </div>




  </div>



  <br>
  <br>







  <!-- TERMINA QUE ES AYUDAME EN  -->

  <!-- EMPIEZA EL CONTENIDO DE SERVICIOS -->
 
  <div style="border-top: 47px solid #121212; ">

    <br>
    <div class="bo container ">
      <h1 style="font-size:45px;      box-shadow: 0 2px 7px rgba(0,0,0,0.2);
    border-radius: 15px;
    padding: 10px;color: white;
      background: #007bff;
      border: 2px solid  #086dda;" class=" my-4 text-center"><b> Servicios <i class="ml-2 far fa-smile-beam"></i></b>
      </h1>

      <div class="row">

        <div class="col-lg-4 mb-4">

          <div class="card h-100">
            <h3 class=" card-header ">Material de educación <i style="font-size: 30px;" class="fas fa-book ml-2"></i>
            </h3>
            <div class="card-body">
              <p class="card-text">Este proporcionara guías hechas por nosotros y algunos docentes en donde te daremos
                maneras
                de aprendizaje las cuales te ayudaran en tu proceso académico para progresar y obtener nuevos
                conocimiento
                estas guías llevaran tareas incluidas para su desarrollo para que lo aprendido se aplique en la vida
                profesional</p>
            </div>

          </div>
        </div>
        <div class="col-lg-4 mb-4">
          <div class="card h-100">
            <h3 class=" card-header">Foro de preguntas<i style="font-size: 34px;" class="far fa-comments ml-4"></i>
            </h3>
            <div class="card-body">
              <p class="card-text">Este te proporcionara la posibilidad de preguntar sobre temas que no entiendas o
                responder preguntas de las cuales puedes tener una respuesta sobre temas académicos nada relacionado con
                lo ilegal y en este se prohíbe el uso inadecuado de las malas palabras haci que por favor sin groserías
                respeten a los demás

                <i class="far fa-smile"></i></p>
            </div>

          </div>
        </div>
        <div class="col-lg-4 mb-4 ">
          <div class="card h-100 ">
            <h3 class="  card-header">Tutoriales con docentes<i style="font-size: 27px;"
                class="fas fa-chalkboard-teacher ml-1 "></i> </h3>
            <div class="card-body">
              <p class="card-text">Este consiste en videos grabados por docentes de nuestra pagina en donde explicaran
                en
                que materia se especializan depuse conceptos teoricos para después pasar a lo practico.este proyecto se
                tomara como algo opcional para aquellas personas que quieran de verdad aprender</p>

            </div>
          </div>
        </div>

      </div>
    </div>

  </div>  

  <section style=" border-bottom:47px solid #121212; margin-top: 34px; border-top: 47px solid #121212;  " class="mou"
  
    class="text-center">
   
    <div style="margin-bottom: -90px; " class="container ">

      <div class="row mb-1">
        
        <div style="margin-top: -55px; " class="col">
          
          <h2><b> Equipo de ayúdame en
              <i class="ml-2 fas fa-users"></i></b></h2>
          <p class="ota"> Equipo de programación de cuartro personas del grado 11a encargado de subdividirse el trabajo
            mutuamente para que la pagina AYUDAME EN este siempre actualizada y este lo mejor optima posible.</p>

          </p>
        </div>
      </div>


      <div class="row">

        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card">

            <div class="inner">
              <img class=" card-img-top" src="img/equipo/ramiro.jpg">
            </div>

            <div class="cam card-footer text-center">



              <h4 class="mb-0">
                <i class="fas fa-user mr-1"></i>Ramiro Pérez<br> </h4>


              <span>
                <i class="fas fa-code"></i> Desarrollador</span>
              <br>
              <i class="fas fa-paint-brush"></i> Diseñador</span>






              <ul class="list-inline"> <br>
                <li class="list-inline-item"><a href="https://www.facebook.com/profile.php?id=100012384707069"
                    class="social-link"><i class=" fab fa-facebook-f"></i></a></li>
                <li class="list-inline-item"><a href="#" class="social-link"><i class="fab fa-twitter"></i></a></li>
                <li class="list-inline-item"><a href="#" class="social-link"><i class="fab fa-instagram"></i></a></li>
              </ul>



            </div>
          </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card">

            <div class="inner">
              <img class=" card-img-top" src="img/equipo/londoño.jpg">
            </div>

            <div class="cam card-footer text-center">


              <h4 class="mb-0">
                <i class="fas fa-user mr-1 "></i>Johan Londoño<br> </h4>


              <span>
                <i class="fas fa-code"></i>Desarrollador</span>
              <br> <i class="fas fa-crown"></i>Fundador</span>





              <ul class="list-inline"> <br>
                <li class="list-inline-item"><a href="https://www.facebook.com/profile.php?id=100012384707069"
                    class="social-link"><i class=" fab fa-facebook-f"></i></a></li>
                <li class="list-inline-item"><a href="#" class="social-link"><i class="fab fa-twitter"></i></a></li>
                <li class="list-inline-item"><a href="#" class="social-link"><i class="fab fa-instagram"></i></a></li>
              </ul>

            </div>
          </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card">

            <div class="inner">
              <img class=" card-img-top" src="img/equipo/rolo.jpg">
            </div>

            <div class="cam card-footer text-center">


              <h4 class="mb-0">
                <i class="fas fa-user mr-1 "></i>Daniel García<br> </h4>


              <span>
                <i class="fas fa-code"></i>Desarrollador</span> <br> <span><i
                  class="fas fa-file-alt"></i>Contenido</span>





              <ul class="list-inline"> <br>
                <li class="list-inline-item"><a href="https://www.facebook.com/profile.php?id=100012384707069"
                    class="social-link"><i class=" fab fa-facebook-f"></i></a></li>
                <li class="list-inline-item"><a href="#" class="social-link"><i class="fab fa-twitter"></i></a></li>
                <li class="list-inline-item"><a href="#" class="social-link"><i class="fab fa-instagram"></i></a></li>
              </ul>

            </div>
          </div>

        </div>


        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card box-shadow">

            <div class="inner">
              <img class=" card-img-top" src="img/equipo/litos1.jpg">
            </div>

            <div class="cam card-footer text-center">



              <h4 class="mb-0"> <i class="fas fa-user mr-1 "></i>Carlos Restrepo <br></h4>




              <span>

                <i class="fas fa-code"></i>Desarrollador</span>
              <br>
              <span><i class="fas fa-pencil-alt"></i>Ortografía</span>



              <ul class="list-inline"> <br>
                <li class="list-inline-item"><a href="https://www.facebook.com/profile.php?id=100012384707069"
                    class="social-link"><i class=" fab fa-facebook-f"></i></a></li>
                <li class="list-inline-item"><a href="#" class="social-link"><i class="fab fa-twitter"></i></a></li>
                <li class="list-inline-item"><a href="#" class="social-link"><i class="fab fa-instagram"></i></a></li>
              </ul>

            </div>
          </div>

        </div>
      </div>
    </div>
    </div>
    <br>
  </section>


  <section style=" margin-top: -50px;margin-bottom: -130px;  
     " style=" color: #fff;">
    <div class="container">
      <div class="xo">
        <h1 style="align-items: center;" class="text-center container col-lg-10"><b>Metas de ayúdame en
            <i class="ml-2 fas fa-star"></i></b></h1>
      </div>
      <div style="margin-top: -50px;" id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <div class=" carousel-inner">
          <div class="carousel-item active">
            <div class="carousel-container">
              <h3 class="v text-center">Objetivo<i class="ml-2 fas fa-crosshairs"></i> </h3>
              <p class="c-o"> Ayudar a la sociedad a solucionar diversos problemas que presentan en diferentes espacios
                de
                aprendizaje brindando autoeducacion por
                dispositivos electrónicos que permitan manejar este sistema web desde distintos lugares .Para una red de
                personas ayudándose entre ellas.</p>


            </div>
          </div>

          <div class="carousel-item">
            <div class="carousel-container">
              <h3 class="v">Misión <i class="ml-2 fas fa-mountain"></i></h3>
              <p class="c-o text-center"> Brindar una ayuda a las personas con dificultades de diferentes áreas del
                aprendizaje mediante un
                sistema web en el que personas capacitadas les brindarán una explicación y unas bases para que estos se
                pueden <br> desarrollar en el área en el que tengan dificultades.
              </p>


            </div>
          </div>
          <div class="carousel-item">
            <div class="carousel-container">
              <h3 class="v text-center">Visión
                <i class="ml-2 fas fa-eye"></i></h3>
              <p class="c-o">Ser reconocidos a nivel internacional como una plataforma de aprendizaje <br> y tambien
                tener una gran cantidad de usuarios que <br> aprendan con Ayudame en <br> te esperamos .
              </p>

            </div>
          </div>
        </div>

        <a class="carousel-control left carousel-control-prev" href="#carouselExampleIndicators" data-slide="prev">
          <i class="fa fa-angle-left"></i>
        </a>
        <a class="carousel-control right carousel-control-next" href="#carouselExampleIndicators" data-slide="next">
          <i class="fa fa-angle-right"></i>
        </a>




      </div>
    </div>
  
  </section>





 







  <!-- empieza footer -->

 
  <footer>

    <div style="border-top:47px solid #121212; " class="b">

      <div class="container">


        <div class="row py-3 d-flex align-items-center">


          <div style="margin-top: -23px;" class="col-md-6 col-lg-6 text-center text-md-left  "><br>
            <h5 style="font-size: 26px;" style="font-weight: bold;" class="mb-0">
              <i style="font-size: 35px;" class="mr-1 fas fa-laugh-beam"></i> SIGUENOS EN NUESTRAS REDES SOCIALES! </h5>
          </div>


          <div style="margin-top: -16px;" class="  col-md-6 col-lg-6 text-center text-md-right">

            <br>


            <li class="list-inline-item"><a href="https://www.facebook.com/ayudameen.proyecayuda.3"
                class="social-link"><i class=" fab fa-facebook-f"></i></a></li>
            <li class="list-inline-item"><a href="https://twitter.com/AYUDAMEEN1" class="social-link"><i
                  class="fab  fa-twitter"></i></a></li>
            <li class="list-inline-item"><a href="https://www.instagram.com/ayuda_me_en/" class="social-link"><i
                  class="fab fa-instagram"></i></a></li>

          </div>
        </div>
      </div>
    </div>

    <div class="container text-center text-md-left mt-5">

      <div class="row mt-3">


        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">


          <h6 style="font-size: 19px;" class="text-uppercase font-weight-bold "><i class="mr-1 fas fa-info-circle"></i>


            <style>



            </style>

            Información de Ayúdame en
          </h6>
          <hr class="color accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 230px; ">
          <p style="font-size: 20px;">Ayúdame en desarrollado con el fin de proporcionar ayudas de tipo académicas
            mediante cursos virtuales y también mediante nuestro foro donde sera una comunidad donde se compartirá el
            conocimiento. Ayúdame en Aqui encontraras todo lo que necesites.</p>

        </div>

        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">


          <h6 style="font-size: 19px;" class="text-uppercase font-weight-bold"><i class="mr-1 fas fa-link"></i>Enlaces
            Rapidos</h6>
          <hr class="color accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 130px;">
          <p>
            <a style="font-size: 22px;" href="index.html">Inicio</a>
          </p>
          <p>
            <a style="font-size: 22px;" href="#">Foro</a>
          </p>

    
          <p>
            <a style="font-size: 22px;" href="Iniciar_sesion.php">Iniciar Sesión </a>
          </p>
          <p>
            <a style="font-size: 22px;" href="Registro.php">Regístrate</a>
          </p>

        </div>



        <div style="margin-top: 18px;" class=" col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
          <h6 style="font-size:20px;" class="text-uppercase font-weight-bold"><i
              class="fas fa-phone-alt mr-1"></i>ContÁctenos</h6>



          <hr class="color accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 230px; ">
          <p class="z">
            <i class="fas fa-home "></i> Col, Antioquia, medellin</p>
          <p class="z">
            <i class="fas fa-envelope "></i> ayudameen.20@outlook.es</p>
          <p class="z">
            <i class="fas fa-phone "></i> 3004687642</p>



        </div>
      </div>
    </div>



    <div class="footer-copyright text-center py-3"><i class="far fa-copyright mr-1"></i>
      2020 AYÚDAME EN - Todos los derechos reservados. contenido recopilado de diferentes fuentes de Información.
    </div>


  </footer>


  <!-- termina footer -->




  <!-- TERMINA EL CONTENIDO COMPLETO DE LA PAGINA PRINCIPAL-->



  <script src="js/jquery-3.4.1.slim.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>

</html>