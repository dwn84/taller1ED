<?php


// conecion a la base localhost

//  $coneccion= mysqli_connect("127.0.0.1","root","","ayudame_en_bd");

$coneccion= mysqli_connect("127.0.0.1","root","","ayudame_en");


// conexion base de datos tonohost
// $coneccion= mysqli_connect("sql107.tonohost.com","ottos_25595196","JSCR25","ottos_25595196_ayudame_en_base_d");

//var_dump($coneccion); //imprime la variable o el array de lo que nos devuelve la conexion

//die(); //detiene el codigo

 $tipo_de_usuario= $_POST["tipo_de_usuario"];
$usuario= $_POST["usuario"];
 $Nombre_y_Apellidos= $_POST["Nombre_y_Apellidos"];
 $genero= $_POST["genero"];
$fecha_de_nacimiento= $_POST["fecha_de_nacimiento"];
 $telefono= $_POST["telefono"];
 $email= $_POST["email"];
 $password= $_POST["password"];


 // echo  "insert into registro(tipo_de_usuario,usuario,Nombre_y_Apellidos,genero,fecha_de_nacimiento,telefono,email,password)values('".$tipo_de_usuario."','".$usuario."','".$Nombre_y_Apellidos."','".$genero."', '".$fecha_de_nacimiento."','".$telefono."','".$email."','".$password."' )";


 $password_incriptada=md5($password);

 if($tipo_de_usuario!="")
 {
 $insertar=mysqli_query( $coneccion, "insert into registro(tipo_de_usuario,usuario,Nombre_y_Apellidos,genero,fecha_de_nacimiento,telefono,email,password)values('".$tipo_de_usuario."','".$usuario."','".$Nombre_y_Apellidos."','".$genero."', '".$fecha_de_nacimiento."','".$telefono."','".$email."','".$password_incriptada."' )" );

}

else{
    $insertar=false;
}



 if($insertar==true)
 {
    ?>
    <script>
    // registro exitoso del tonohost
    //   window.location.href="http://ayudame-en.tonohost.com/Registro_exitoso.php";

    // registro exitoso del localhost 
    window.location.href="http://localhost/AYUDAME_EN/Registro_exitoso.php";
    </script>

<?php
 }
 else{
?>
    <script>
    // registro no exitoso del tonohost
    //  window.location.href="http://ayudame-en.tonohost.com/Registro_no_exitoso.php";

    // registro no exitoso del locslhost 
      window.location.href="http://localhost/AYUDAME_EN/Registro_no_exitoso.php";
    </script> 

    <?php
 }
?>