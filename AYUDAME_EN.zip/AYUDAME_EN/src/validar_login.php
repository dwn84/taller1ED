<?php


// conecion a la base de datos localhost

 $coneccion= mysqli_connect("127.0.0.1","root","","ayudame_en");

// conexion base de datos tonohost
//  $coneccion= mysqli_connect("sql107.tonohost.com","ottos_25595196","JSCR25","ottos_25595196_ayudame_en_base_d");

//var_dump($coneccion); //imprime la variable o el array de lo que nos devuelve la conexion

//die(); //detiene el codigo
$tipo_usuario= $_POST["tipo_usuario"];
$usuario= $_POST["nom_usuario"];
$email= $_POST["email"];
$password= $_POST["password_usuario"];

$password_dig_for_incrip=md5($password);



$consultar_usuario_en_bd=mysqli_query($coneccion,"select tipo_de_usuario, usuario, email,password from registro");


while($dato_uno_por_uno=mysqli_fetch_array($consultar_usuario_en_bd))
{
  $tipo_usuario_bd=$dato_uno_por_uno["tipo_de_usuario"];
  $usuario_bd=$dato_uno_por_uno["usuario"];
  $email_bd=$dato_uno_por_uno["email"];

   
  $password_bd=$dato_uno_por_uno["password"];


  if($tipo_usuario==$tipo_usuario_bd)
  {

   if($usuario==$usuario_bd)
 {

  if($email==$email_bd)
 {
        ///valido que el email es correcto

        if($password_dig_for_incrip==$password_bd)
        {
          session_start();
          $_SESSION["nivelUsuario"]=$tipo_usuario_bd;

         
            //  echo"Su contraseña es correcta :)";
            //  die();

                   
   ?>
    <script>
   //backend_usuario del tonohost
    // window.location.href="http://ayudame-en.tonohost.com/backend_usuario.php";

  //backend_usuario del localhost 
     window.location.href="http://localhost/AYUDAME_EN/backend_usuario.php?usuario=<?php echo $usuario_bd?>";
    </script>

  <?php

 
}
}  



}
}
 

}   




  

?>

<script>
        //contraseña_incorrecta del tonohost
        // window.location.href="http://ayudame-en.tonohost.com/contraseña_de_inciar_sesion_incorrecta.php";

         //contraseña_incorrecta del localhost
         window.location.href="http://localhost/AYUDAME_EN/contraseña_de_inciar_sesion_incorrecta.php";
        </script>