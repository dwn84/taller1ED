<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/bootstrap.min.css">
<!-- <link rel="stylesheet" href="css/Regístrate.css" > -->
  <link rel="stylesheet" href="css/all.css"> 





  <title>AYÚDAME EN</title>
<style>
.alert-success{
  background: rgba(0, 0, 0, 0.7);
padding: 20px;
border-radius:  20px;
color: white;
border: 7px solid #ffffff ;
}

,h1{
   color:#b9d1bf;
   font-size:25px;
 }
 p{
   font-size:17px;
   color:#b9d1bf;
 }
 body{
  background-color: #b9d1bf;
}
</style>
</head>
<body>
<br>
<br>

    <div  class="container text-center">
     <div class="alert alert-success" role="alert">

     <a href="index.php" ><img class="mb-4 " src="img/logo1.png" width="78" height="72"></a>

      <h4 style="color:#b9d1bf;"  class="alert-heading text-center">REGISTRO EXITOSO
<i class="fas fa-smile"></i> !</h4>
      <hr>
     <p style=" color:#ffff;" class="text-center">Que bien  
     <i class="fas fa-smile"></i>  !<br> Ahora tu haces parte de la familia de ayùdame en <i class="fas fa-smile"></i>! <br> Gracias por hacer su registro de manera exitosa.</p>
     <br>
     <br>
  
      <p style=" color:#ffff;" class="text-center">Volver a  página principal</p>
              <li   class="list-inline-item"><a style="color:#fff;" href="index.php"><i  class="  fa-2x fa-lg 
                       fas fa-arrow-circle-left"> </i></a></li>
                       <hr>
                       <p style="font-family:Sans-serif; font-weight: bold; " class="mb-0 text-center">Para mas informaciòn con respecto a errores comuniquese con el area de soporte  al siquiente correo electronico </p>
                       <p style="font-family:Sans-serif; font-weight: bold; ">ayudameen.20@outlook.es </p>
   </div>
 </div>

<script src="js/jquery-3.4.1.slim.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>

</html>