
<?php

// conecion a la base de datos localhost

 $coneccion= mysqli_connect("127.0.0.1","root","","ayudame_en");

// conexion base de datos tonohost
// $coneccion= mysqli_connect("sql107.tonohost.com","ottos_25595196","JSCR25","ottos_25595196_ayudame_en_base_d");
?>



<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/estilos.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/css_de_estilos_materias.css">
  <link rel="stylesheet" href="css/botones_estilo.css">
  <link rel="stylesheet" href="css/all.css">
  <link rel="stylesheet" href="css/redes_sociales.css">
  <link rel="stylesheet" href="css/footer.css">
  <link href="https://fonts.googleapis.com/css?family=Titillium+Web:400,600" rel="stylesheet">
  <title>AYÚDAME EN</title>
  <style>


.btn-block {
      -webkit-transform: scale(1, 1);
      -webkit-transition-timing-function: ease-out;
      -webkit-transition-duration: 250ms;
      -moz-transform: scale(1, 1);
      -moz-transition-timing-function: ease-out;
      -moz-transition-duration: 250ms;
    }

    .btn-block:hover {
      -webkit-transform: scale(1.10, 1.10);
      -webkit-transition-timing-function: ease-out;
      -webkit-transition-duration: 170ms;
      -moz-transform: scale(1.10, 1.10);
      -moz-transition-timing-function: ease-out;
      -moz-transition-duration: 170ms;
    }




   

    .form-control {
      background: rgba(0, 0, 0, 0.924) !important;
      border-style: none;
      transition: 0.3s ease-in;
      outline: none;
      border: 1px solid rgb(255, 255, 255) !important;
    }



body {
      color: white;
      font-family: 'Titillium Web', sans-serif !important;
    }


    label{
      font-size:19px;
    }

    .editar{
      background: #2fb64e;
  border-radius: 0.5rem;
  letter-spacing: .1rem;
  font-weight: bold;
  padding: 0.8rem;
  transition: all 0.3s;
        font-size: 20px;      
       border: 3px solid #2ba849;
       box-shadow: 0 3px 7px rgba(0,0,0,0.2);
    }

.editar:hover{

  border: 3px solid #2ba849;
}

.dropdown-menu{
  background: #131313!important; 
  border:1px solid #1e2227;border-radius: 10px;
}

.dropdown-item{
  color:#fff!important;
  background: #131313!important;
}
.dropdown-item:hover{
background:#2fb64e!important;
border-radius: 2px;
}

.navbar{
  background: #131313!important; 
border-bottom:1px solid  #343a40;
}




.morlum {
      border: 2px solid rgb(255, 255, 255);
      background: rgba(0, 0, 0, 0.7);
      padding: 20px;
      border-radius: 1rem;
      padding: 40px;
      margin-top: 10px;
      transition: all 0.3s;
    }

    .morlum:hover {
      border: 2px solid #2fb64e;
      box-shadow: 0 2px 10px #2ba8486e;
      background: rgba(0, 0, 0, 0.8);
      padding: 20px;
      border-radius: 1rem;
      padding: 40px;
      margin-top: 10px;
    }
</style>
</head>

<body>

<nav  class="navbar navbar-expand-xl bg-dark navbar-dark fixed-top">
    <a href="index.php" class="zoom navbar-brand "><img src="img/logo1.png" width="110" height="89"></a>

    <button class="navbar-toggler " type="button" data-toggle="collapse" data-target="#uno">
      <span class="navbar-toggler-icon"></span>
    </button>


    <div class="collapse navbar-collapse" id="uno">

      <ul class="navbar-nav mr-auto  ">

        <li  class="nav-item dropdown mr-2">
          <a href="" class="su nav-link dropdown-toggle mr-1" data-toggle="dropdown">
            <i class="fas fa-baby mr-2"></i>Primaria </a>
          <div  class="dropdown-menu">
            <a href="preescolar.html" class="dropdown-item">Preescolar<i class="fas fa-apple-alt ml-2"></i></a>
            <a href="1.html" class="dropdown-item">Primero 1º</a>
            <a href="2.html" class="dropdown-item">Segundo 2º</a>
            <a href="3.html" class="dropdown-item">Tercero 3º</a>
            <a href="4.html" class="dropdown-item">Cuarto 4º</a>
            <a href="5.html" class="dropdown-item">Quinto 5º</a>
          </div>
        </li>
        <li class="nav-item dropdown mr-2">
          <a href="" class="su nav-link dropdown-toggle mr-1" data-toggle="dropdown">
            <i class="fas fa-child mr-2"></i>Secundaria </a>

          <div class="dropdown-menu">
            <a href="6.html" class="dropdown-item">Sexto 6º</a>
            <a href="7.html" class="dropdown-item">Séptimo 7º</a>
            <a href="8.html" class="dropdown-item">Octavo 8º</a>
            <a href="9.html" class="dropdown-item">Noveno 9º</a>
            <a href="10.html" class="dropdown-item">Décimo 10º</a>
            <a href="11.html" class="dropdown-item">Undécimo 11º</a>
          </div>

        </li>

        <li class="nav-item dropdown mr-2">
          <a href="#" class="su nav-link dropdown-toggle mr-1" data-toggle="dropdown">

            <i class="fas fa-graduation-cap mr-2"></i>Medias técnicas </a>
          <div class="dropdown-menu">
            <a href="software.html" class="dropdown-item"> Desarrollo de Software<i style="font-size: 23px;" class="fas fa-laptop-code ml-2"></i></a>
            <a href="preprensa.html" class="dropdown-item">Preprensa<i style="font-size: 23px;" class="fas fa-paint-brush ml-2"></i></a>
            <a href="recursoshumano.html" class="dropdown-item">Recursos humanos<i style="font-size: 23px;" class="fas fa-user-tie ml-2"></i></a>
          </div>
        </li>
      
    
        <li class="nav-item">
          <a href="" class="su nav-link "><i  class="far fa-comments mr-2"></i>Foro</a>
      </li>

        <li class="nav-item dropdown mr-2">
          <a href="#" class="su nav-link dropdown-toggle mr-1" data-toggle="dropdown"><i class="fas fa-male mr-2"></i></i>Usuario BD</a> 
          <div class="dropdown-menu">
          <a href="Consultar_usuarios.php" class="dropdown-item">Consultar Usuarios Activos<i  class="fas fa-user-check ml-2"></i></a>
            <a href="Consultar_usuarios_inactivos.php" class="dropdown-item">Consultar Usuarios Inactivos<i   class="fas fa-user-times ml-2"></i></a>
          </div>
        </li>



    
        


         

      </ul>

         <!-- COMIENZA FORMULARIO -->
         <div class="d-flex flex-row justify-content">
        <a href="Iniciar_sesion.php" class="Q btn btn-lg btn-primary mr-3 n"><i class="fas fa-user"></i>
          Iniciar Sesión </a>
        <a style="margin-left:-0px;" href="Registro.php" class="Q btn btn-lg btn-primary n"><i
            class="fas fa-sign-in-alt mr-1"></i>Regístrate</a>
        <!-- TERMINA FORMULARIO -->

      </div>
    </div>

  </nav>




<br>
<br>
<br>
<br>
<br>

<br>

     
<div  style="marigin-top:-10px;"  class="xo container morlum">

<h1 class=" text-center"> <b> Editar Usuario <i  class="fas fa-edit"></i> </b></h1>



<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE);
$coneccion=mysqli_connect("127.0.0.1","root","","ayudame_en");

$id_del_usuario_a_consultar=$_GET["id_usuario"];
$eliminar=$_GET["eliminar"];

if($eliminar=="si")
{
  mysqli_query($coneccion,"update  registro set Activo='no'  where id='".$id_del_usuario_a_consultar."' ");
  ?>
  <script>
      window.location.href="Consultar_usuarios.php";
  </script>

<?php
}

if($eliminar=="no")
{
  mysqli_query($coneccion,"update  registro set Activo='si'  where id='".$id_del_usuario_a_consultar."' ");
  ?>
  <script>
      window.location.href="Consultar_usuarios_inactivos.php";
  </script>

<?php
}



$consulta_usuario=mysqli_query($coneccion , "select * from  registro where id='".$id_del_usuario_a_consultar."' ");

$info_usuario_en_array=mysqli_fetch_array($consulta_usuario);

$idquien_Se_edita=$_GET["editar_id"];

if($idquien_Se_edita)
{
    mysqli_query($coneccion, "update  registro set tipo_de_usuario='".$_POST["Tipo_de_usuario_edit"]."' , usuario='".$_POST["usuario_edit"]."' 
    , Nombre_y_Apellidos='".$_POST["Nombre_y_Apellidos_edit"]."',  genero='".$_POST["genero_edit"]."',  fecha_de_nacimiento='".$_POST["fecha_de_nacimiento_edit"]."'
    ,  telefono='".$_POST["telefono_edit"]."' , email='".$_POST["email_edit"]."', password='".$_POST["password_edit"]."'
    where id='".$idquien_Se_edita."'  ");

    ?>
  <script>
      window.location.href="Consultar_usuarios.php";
  </script>


<?php
}


?>


<form method="POST" action="editar_informacion.php?editar_id=<?php echo $id_del_usuario_a_consultar; ?>">
    
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Tipo de usuario</label>
     
      <input type="text"name="Tipo_de_usuario_edit"   class="form-control text-white" value=" <?php echo $info_usuario_en_array["tipo_de_usuario"];?>">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">usuario</label>
      <input  type="text" name="usuario_edit" class="form-control text-white" value=" <?php echo $info_usuario_en_array["usuario"];?>">
    </div>
  </div>
  <div class="form-row">
  <div class="form-group col-md-6">
    <label for="inputAddress">Nombres y apellidos</label>
    <input type="text" name="Nombre_y_Apellidos_edit" class="form-control text-white" value=" <?php echo $info_usuario_en_array["Nombre_y_Apellidos"];?>">
  </div>
  <div class="form-group col-md-6">
    <label for="inputAddress2">Genero</label>
    <input type="text" name="genero_edit" class="form-control text-white " value=" <?php echo $info_usuario_en_array["genero"];?>">
  </div>
</div>
  <div class="form-row">
    <div class="form-group col-md-2">
      <label for="inputCity">Fecha de nacimiento</label>
      
<input type="text" name="fecha_de_nacimiento_edit" class="form-control text-white" value=" <?php echo $info_usuario_en_array["fecha_de_nacimiento"];?>">
    </div>
    <div class="form-group col-md-4">
      <label for="inputState">Telefono</label>
      <input type="text" name="telefono_edit" class="form-control text-white" value=" <?php echo $info_usuario_en_array["telefono"];?>">
    </div>
    <div class="form-group col-md-6">
      <label for="inputZip">Email</label>
      <input type="email" name="email_edit" class="form-control text-white" value=" <?php echo $info_usuario_en_array["email"];?>">
    </div>
  </div>


<div class="form-row">
  <div class="form-group col-md-12">
      <label for="inputZip">Contraseña</label>
      <input type="text" name="password_edit" class="form-control text-white" value=" <?php echo $info_usuario_en_array["password"];?>">
    </div>
</div>





  <button  type="submit" class="btn-block editar btn-success">Editar informaciòn<i  class="fas fa-edit ml-1"></i> </button>

</form>






<br>

</div>






<br>
<br>
<br>
 
  <!-- empieza footer -->
  <!-- empieza footer -->

  <footer>

    <div style="border-top:47px solid #121212; " class="b">

      <div class="container">


        <div class="row py-3 d-flex align-items-center">


          <div style="margin-top: -23px;" class="col-md-6 col-lg-6 text-center text-md-left  "><br>
            <h5 style="font-size: 26px;" style="font-weight: bold;" class="mb-0">
              <i style="font-size: 35px;" class="mr-1 fas fa-laugh-beam"></i> SIGUENOS EN NUESTRAS REDES SOCIALES! </h5>
          </div>


          <div style="margin-top: -16px;" class="  col-md-6 col-lg-6 text-center text-md-right">

            <br>


            <li class="list-inline-item"><a href="https://www.facebook.com/ayudameen.proyecayuda.3"
                class="social-link"><i class=" fab fa-facebook-f"></i></a></li>
            <li class="list-inline-item"><a href="https://twitter.com/AYUDAMEEN1" class="social-link"><i
                  class="fab  fa-twitter"></i></a></li>
            <li class="list-inline-item"><a href="https://www.instagram.com/ayuda_me_en/" class="social-link"><i
                  class="fab fa-instagram"></i></a></li>

          </div>
        </div>
      </div>
    </div>

    <div class="container text-center text-md-left mt-5">

      <div class="row mt-3">


        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">


          <h6 style="font-size: 19px;" class="text-uppercase font-weight-bold "><i class="mr-1 fas fa-info-circle"></i>


            <style>



            </style>

            Información de Ayúdame en
          </h6>
          <hr class="color accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 230px; ">
          <p style="font-size: 20px;">Ayúdame en desarrollado con el fin de proporcionar ayudas de tipo académicas
            mediante cursos virtuales y también mediante nuestro foro donde sera una comunidad donde se compartirá el
            conocimiento. Ayúdame en Aqui encontraras todo lo que necesites.</p>

        </div>

        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">


          <h6 style="font-size: 19px;" class="text-uppercase font-weight-bold"><i class="mr-1 fas fa-link"></i>Enlaces
            Rapidos</h6>
          <hr class="color accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 130px;">
          <p>
            <a style="font-size: 22px;" href="index.html">Inicio</a>
          </p>
          <p>
            <a style="font-size: 22px;" href="Contáctenos.html">Contáctenos</a>
          </p>
          <p>
            <a style="font-size: 22px;" href="Iniciar_sesion.php">Iniciar Sesión </a>
          </p>
          <p>
            <a style="font-size: 22px;" href="Registro.php">Regístrate</a>
          </p>

        </div>



        <div style="margin-top: 18px;" class=" col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
          <h6 style="font-size:20px;" class="text-uppercase font-weight-bold"><i
              class="fas fa-phone-alt mr-1"></i>ContÁctenos</h6>



          <hr class="color accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 230px; ">
          <p class="z">
            <i class="fas fa-home "></i> Col, Antioquia, medellin</p>
          <p class="z">
            <i class="fas fa-envelope "></i> ayudameen.20@outlook.es</p>
          <p class="z">
            <i class="fas fa-phone "></i> 3004687642</p>



        </div>
      </div>
    </div>



    <div class="footer-copyright text-center py-3"><i class="far fa-copyright mr-1"></i>
      2020 AYÚDAME EN - Todos los derechos reservados. contenido recopilado de diferentes fuentes de Información.
    </div>


  </footer>


  
  <!-- termina footer -->

  <!-- termina footer -->



  <!--TERMINA EL CONTENIDO DE NOVENO-->




  <script src="js/jquery-3.4.1.slim.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>

</html>