<?php
session_start();

if (isset($_SESSION["idUsuario"])){
    $coneccion= mysqli_connect("127.0.0.1","root","","ayudame_en");
    

    if(isset($_POST['grados'])){
        if(isset($_POST['grados']) && is_array($_POST['grados'])){
            $arr = array();
            foreach($_POST['grados'] as $g){
                if($g>=1 && $g<=5){
                    $nivel = 1;
                }else if($g<=6){
                    $nivel = 2;
                }else if($g="mtds2"){
                    $nivel = 3;
                    $g = 2;
                }else if($g="mtds1"){
                    $nivel = 3;
                    $g = 1;
                }else if($g="mtpp1"){
                    $nivel = 3;
                    $g = 1;
                }
                
                $consulta = "insert into nivel_estudiante values($_SESSION[idUsuario],$nivel,$g)";
                mysqli_query($coneccion, $consulta);

            }

            /* cerrar la conexión */
            mysqli_close($link);
            header("Location:../backend_usuario.php?usuario=$_SESSION[usuario]");

        }
    }
    
}else{
   echo"Error: no se ha iniciado sesion...";
} 

?>