
<?php


echo "
  
  <!-- navbar de administrador-->
  <nav  class='navbar navbar-expand-xl bg-dark navbar-dark fixed-top'>
      <a href='index.php' class='zoom navbar-brand '><img src='img/logo1.png' width='110' height='89'></a>
  
      <button class='navbar-toggler ' type='button' data-toggle='collapse' data-target='#uno'>
        <span class='navbar-toggler-icon'></span>
      </button>
  
  
      <div class='collapse navbar-collapse' id='uno'>
  
        <ul class='navbar-nav mr-auto  '>
  
          <li  class='nav-item dropdown mr-1'>
            <a href='' class='su nav-link dropdown-toggle ' data-toggle='dropdown'>
              <i class='fas fa-baby mr-1'></i>Primaria </a>
            <div  class='dropdown-menu'>
              <a href='preescolar.html' class='dropdown-item'>Preescolar<i class='fas fa-apple-alt ml-2'></i></a>
              <a href='1.html' class='dropdown-item'>Primero 1º</a>
              <a href='2.html' class='dropdown-item'>Segundo 2º</a>
              <a href='3.html' class='dropdown-item'>Tercero 3º</a>
              <a href='4.html' class='dropdown-item'>Cuarto 4º</a>
              <a href='5.html' class='dropdown-item'>Quinto 5º</a>
            </div>
          </li>
          <li class='nav-item dropdown mr-1'>
            <a href='' class='su nav-link dropdown-toggle ' data-toggle='dropdown'>
              <i class='fas fa-child mr-1'></i>Secundaria </a>
  
            <div class='dropdown-menu'>
              <a href='6.html' class='dropdown-item'>Sexto 6º</a>
              <a href='7.html' class='dropdown-item'>Séptimo 7º</a>
              <a href='8.html' class='dropdown-item'>Octavo 8º</a>
              <a href='9.html' class='dropdown-item'>Noveno 9º</a>
              <a href='10.html' class='dropdown-item'>Décimo 10º</a>
              <a href='11.html' class='dropdown-item'>Undécimo 11º</a>
            </div>
  
          </li>
  
          <li class='nav-item dropdown mr-1'>
            <a href='#' class='su nav-link dropdown-toggle ' data-toggle='dropdown'>
  
              <i class='fas fa-graduation-cap '></i>Medias técnicas </a>
            <div class='dropdown-menu'>
              <a href='software.html' class='dropdown-item'> Desarrollo de Software<i style='font-size: 23px;' class='fas fa-laptop-code ml-2'></i></a>
              <a href='preprensa.html' class='dropdown-item'>Preprensa<i style='font-size: 23px;' class='fas fa-paint-brush ml-2'></i></a>
              <a href='recursoshumano.html' class='dropdown-item'>Recursos humanos<i style='font-size: 23px;' class='fas fa-user-tie ml-2'></i></a>
            </div>
          </li>
        
      
          <li class='nav-item  mr-1'>
            <a href='' class='su nav-link mr-1 '><i  class='far fa-comments mr-1'></i>Foro</a>
        </li>
  
  
  
          <li class='nav-item dropdown '>
            <a href='#' class='su nav-link dropdown-toggle ' data-toggle='dropdown'><i class='fas fa-male mr-2'></i>Usuario BD</a> 
            <div class='dropdown-menu'>
            <a href='Consultar_usuarios.php' class='dropdown-item'>Consultar Usuarios Activos<i  class='fas fa-user-check ml-2'></i></a>
              <a href='Consultar_usuarios_inactivos.php' class='dropdown-item'>Consultar Usuarios Inactivos<i   class='fas fa-user-times ml-2'></i></a>
            </div>
          </li>
        </ul>
  
        <li   class=' nav-item dropdown list-inline-item mr-5' ><a class='nav-link dropdown-toggle usuario mr-3' data-toggle='dropdown' style='font-size:27px;color:#fff; font-weight:bold ;' href=''>  <?php echo $_GET[usuario]; ?><i style='font-size:30px;' class=' ml-2 fas fa-user-circle'></i></a>
  
  <div class='dropdown-menu '>
  <a  style='font-size:21px;' href='perfil.html' class='dropdown-item'><b> Perfil<i  class='fas fa-user-alt ml-2'></i></b></a>
     <a style='font-size:21px;' href='cerrar_sesion.php' class='dropdown-item'><b>Cerrar  Sesión<i class='fas fa-power-off ml-2'></i></b></a>
  
  
   </div>
  </li>
  
  
        </div>
      </div>
  
    </nav>
  
  
    ";

?>