<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/estilos.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/css_de_estilos_materias.css">

  <link rel="stylesheet" href="css/all.css">
  <link rel="stylesheet" href="css/redes_sociales.css">
  <link rel="stylesheet" href="css/footer.css">
  <link href="https://fonts.googleapis.com/css?family=Titillium+Web:400,600" rel="stylesheet">
  <title>AYÚDAME EN</title>



  


  <title>AYÚDAME EN</title>


<style>
    .h header {
      background-image: url('img/contactenos/3.jpg');
      height: 60%;
      background-repeat: no-repeat;
      background-size: cover;
      background-attachment: fixed;
      box-shadow: 0 6px 10px rgba(175, 175, 175, 0.2);
      border-bottom: 2px solid #ffffff;
      transition: all 0.3s;
    }


    .list-group a {


      background: #2fb64e;
      border-radius: 15px;
      letter-spacing: .1rem;
      font-weight: bold;
      padding: 0.6rem;
      transition: all 0.3s;
      font-size: 20px;
      border: 3px solid #2aa045;
      margin: 5px;
      color: #fff;
      box-shadow: 0 3px 7px rgba(0, 0, 0, 0.2);
    }

    .list-group a:hover {
      background: #007bff;
      border-radius: 15px;
      letter-spacing: .1rem;
      font-weight: bold;
      padding: 0.6rem;
      transition: all 0.3s;
      font-size: 20px;
      border: 3px solid #086dda !important;
      color: #fff;
      margin: 5px;
      box-shadow: 0 3px 7px rgba(167, 59, 59, 0.2);
    }



    .terbu {
      border: 2px solid #fff;
      padding: 18px;
      background: #131313;
      border-radius: 16px;
      transition: all 0.3s;
      text-align: center;
      box-shadow: 0 2px 7px rgba(175, 175, 175, 0.2);
    }


    .terbu:hover {
      border: 2px solid #2aa045;
      padding: 18px;
      border-radius: 16px;
      background: #0a0a0a;
      box-shadow: 0 10px 15px #2ba8486e;
      transition: all 0.3s;
    }

    .xo ul {
      font-size: 21px;
      box-shadow: 0 1px 7px rgba(175, 175, 175, 0.2);
      border-radius: 15px;
      padding: 28px;
      background: #131313;
      border: 2px solid rgb(255, 255, 255);
      margin-bottom: 1.25rem;
      color: #fff !important;
      transition: all 0.3s;

    }

    .xo ul:hover {
      background: #0a0a0a;
      border: 2px solid #007bff;
      box-shadow: 0 3px 10px #007bff57;
    }

    .usuario{
  color: rgba(255, 255, 255, 0.664)!important;
  }

  .usuario:hover{
    color: rgba(255, 255, 255, 0.863)!important;
  }
  </style>
</head>

<body >

<?php

session_start();
if (isset($_SESSION["nivelUsuario"])){
  if($_SESSION["nivelUsuario"]==2){
  //ha ingresado un administrador
    include 'menu_admin.php';
  }else if($_SESSION["nivelUsuario"]==1){
  //ha ingresado un aprendiz

  //validar si el aprendiz ya tiene asignado un grado

  $coneccion= mysqli_connect("127.0.0.1","root","","ayudame_en");

  $consulta ="SELECT id FROM nivel_estudiante ne join registro r on ne.idEstudiante = r.id where r.usuario = '$_GET[usuario]'";

  if ($resultado = mysqli_query($coneccion, $consulta)) {
    
    $row_cnt = mysqli_num_rows($resultado);
    echo $row_cnt;
    if($row_cnt == 0){
      $consultaId ="SELECT id FROM registro where usuario = '$_GET[usuario]'";
      $resultadoId = mysqli_query($coneccion, $consultaId);
      $dato=mysqli_fetch_array($resultadoId, MYSQLI_ASSOC);
      $_SESSION["idUsuario"]=$dato["id"];
      $_SESSION["usuario"]=$_GET["usuario"];
      include 'solicitar_grados.php';
    }else{
      include 'menu_aprendiz.php';
    }


    

  }else{
    echo 'Error interno, contacte al administrador';

  }
  mysqli_close($coneccion);





    
  }else{
  //ha ingresado un profesor
   //include 'menu_profe.php';
   echo "Menu de profe...";
  }
  
}else{
  //estan tratando de entrar sin iniciar sesion...
  echo "Error...";
}         

?>

<!-- EMPIEZA CONTENIDO DE SEGUNDO -->


<div class="container h ">
    <br>
    <br>
    <br>


    <!-- EMPIEZA ENCABEZADO DE SEGUNDO-->

    <header class=" jumbotron my-4 col-sm-12 col-md-12 col-lg-12 col-xl-12 ">

      <h1 class="display-3 text-light text-center">CURSOS<i class="fas fa-chalkboard-teacher ml-2"></i>
      </h1>
      <p class="lead text-light text-center"> Bienvenido elige un curso de un grado ,area o
        mediatecnica en donde aprenderás lo mejor de lo mejor que te ofrece ayúdame en.<i style="font-size: 30px;"
          class="far fa-laugh-beam ml-2"></i></p>

    </header>

    <!--TERMINA ENCABEZADO DE SEGUNDO -->


    <!-- EMPIEZA QUE ES SEGUNDO-->

  </div>



  <br>












  <div class="container">
    <div class="row">
      <div class="  col-12 mt-1 ">
        <div class="xo">
          <h1 class="text-center"><b> Elige lo que quieres
              aprender <i class="far fa-hand-point-down"></i></b> </h1>

        </div>
        <br>
        <div class="list-group xo">


          <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">

            <li class="nav-item" role="presentation">
              <a style=" margin-top:15px;border-radius: 0.7rem;" class="list-group-item " id="pills-preescolar-tab"
                data-toggle="pill" href="#pills-preescolar" role="tab" aria-controls="pills-preescolar"
                aria-selected="true">Preescolar</a>
            </li>
            <li class="nav-item" role="presentation">
              <a style=" margin-top:15px;border-radius: 0.7rem;" class="list-group-item " id="pills-primero-tab"
                data-toggle="pill" href="#pills-primero" role="tab" aria-controls="pills-primero"
                aria-selected="false">Primero 1º</a>
            </li>
            <li class="nav-item" role="presentation">
              <a style=" margin-top:15px;border-radius: 0.7rem;" class="list-group-item " id="pills-segundo-tab"
                data-toggle="pill" href="#pills-segundo" role="tab" aria-controls="pills-segundo"
                aria-selected="false">Segundo 2º</a>
            </li>
            <li class="nav-item" role="presentation">
              <a style=" margin-top:15px;border-radius: 0.7rem;" class="list-group-item " id="pills-tercero-tab"
                data-toggle="pill" href="#pills-tercero" role="tab" aria-controls="pills-tercero"
                aria-selected="false">Tercero 3º</a>
            </li>
            <li class="nav-item" role="presentation">
              <a style=" margin-top:15px;border-radius: 0.7rem;" class="list-group-item " id="pills-cuarto-tab"
                data-toggle="pill" href="#pills-cuarto" role="tab" aria-controls="pills-cuarto"
                aria-selected="false">Cuarto 4º</a>
            </li>


            <li class="nav-item" role="presentation">
              <a style=" margin-top:15px;border-radius: 0.7rem;" class="list-group-item " id="pills-quinto-tab"
                data-toggle="pill" href="#pills-quinto" role="tab" aria-controls="pills-quinto"
                aria-selected="false">Quinto 5º</a>
            </li>

            <li class="nav-item" role="presentation">
              <a style=" margin-top:15px;border-radius: 0.7rem;" class="list-group-item " id="pills-sexto-tab"
                data-toggle="pill" href="#pills-sexto" role="tab" aria-controls="pills-sexto"
                aria-selected="false">Sexto 6º</a>
            </li>

            <li class="nav-item" role="presentation">
              <a style=" margin-top:15px;border-radius: 0.7rem;" class="list-group-item " id="pills-septimo-tab"
                data-toggle="pill" href="#pills-septimo" role="tab" aria-controls="pills-septimo"
                aria-selected="false">Séptimo 7º</a>
            </li>

            <li class="nav-item" role="presentation">
              <a style=" margin-top:15px;border-radius: 0.7rem;" class="list-group-item " id="pills-octavo-tab"
                data-toggle="pill" href="#pills-octavo" role="tab" aria-controls="pills-octavo"
                aria-selected="false">Octavo 8º</a>
            </li>
            <li class="nav-item" role="presentation">
              <a style=" margin-top:15px;border-radius: 0.7rem;" class="list-group-item " id="pills-noveno-tab"
                data-toggle="pill" href="#pills-noveno" role="tab" aria-controls="pills-noveno"
                aria-selected="false">Noveno 9º</a>
            </li>

            <li class="nav-item" role="presentation">
              <a style=" margin-top:15px;border-radius: 0.7rem;" class="list-group-item " id="pills-decimo-tab"
                data-toggle="pill" href="#pills-decimo" role="tab" aria-controls="pills-decimo"
                aria-selected="false">Décimo 10º</a>
            </li>

            <li class="nav-item" role="presentation">
              <a style=" margin-top:15px;border-radius: 0.7rem;" class="list-group-item " id="pills-undecimo-tab"
                data-toggle="pill" href="#pills-undecimo" role="tab" aria-controls="pills-undecimo"
                aria-selected="false">Undécimo 11º</a>
            </li>
            <li class="nav-item" role="presentation">
              <a style=" margin-top:15px;border-radius: 0.7rem;" class="list-group-item " id="pills-software-tab"
                data-toggle="pill" href="#pills-software" role="tab" aria-controls="pills-software"
                aria-selected="false">Desarrollo de Software<i style="font-size: 23px;"
                  class="fas fa-laptop-code ml-2"></i></a>
            </li>
            <li class="nav-item" role="presentation">
              <a style=" margin-top:15px;border-radius: 0.7rem;" class="list-group-item " id="pills-preprensa-tab"
                data-toggle="pill" href="#pills-preprensa" role="tab" aria-controls="pills-preprensa"
                aria-selected="false">Preprensa<i style="font-size: 23px;" class="fas fa-paint-brush ml-2"></i></a>
            </li>
            <li class="nav-item" role="presentation">
              <a style=" margin-top:15px;border-radius: 0.7rem;" class="list-group-item " id="pills-humanos-tab"
                data-toggle="pill" href="#pills-humanos" role="tab" aria-controls="pills-humanos"
                aria-selected="false">Recursos humanos<i style="font-size: 23px;" class="fas fa-user-tie ml-2"></i></a>
            </li>


          </ul>
        </div>
      </div>
    </div>
  </div>

  <br>

  <div style="border-top:47px solid #121212;  ">
    <br> <br>
    <div class="container">

      <div class="tab-content" id="pills-tabContent">


        <div class="tab-pane fadeshow active text-white" id="pills-dddddd" role="tabpanel"
          aria-labelledby="pills-ddd-tab">
          <div class="container c-o">
            <h1><b> <i style="font-size: 60px!important;" class="far fa-hand-point-up mr-2"></i>No has elegido que aprender? por
                favor elige que quieres aprender en la parte superior tienes muchas opciones escoge la mejor opción para
                ti ayúdame en. <i class="far fa-laugh-wink"></i></b>
            </h1>
          </div>

          <br>
          <br>
        </div>

        <div class="tab-pane fade " id="pills-preescolar" role="tabpanel" aria-labelledby="pills-preescolar-tab">




          <div class="container">

            <div class="xo">

              <h1 class="text-center  "><b><i class="fas fa-apple-alt "></i> Cursos de Preescolar<i
                    style="font-size: 38px;" class="ml-3 fas fa-book"></i></b></h1>


              <p class="text-center ">Esperamos que te guste el contenido de preescolar de primaria de ayúdame en. <i
                  style="font-size:40px;" class="far fa-smile-wink"></i></p>
            </div>


            <br>
            <!-- EMPIEZA MATERIAS DE PREESCOLAR-->

            <div class=" row text-center f">

              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="  card  h-100 ">
                  <div class="inner">
                    <img class=" card-img-top" src="img/Preescolar/español.jpg" width="400px" height="180px">
                  </div>
                  <div class=" card-body">
                    <h4 class="card-title" style="font-weight:bold ;">Español</h4>
                    <p class="card-text">Inicia tu aprendizaje de español para preescolar contenido de ayúdame en.</p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>

              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T  card h-100">
                  <div class="inner">
                    <img class="card-img-top" class="rounded-top" src="img/Preescolar/mate.jpg" width="400px"
                      height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Matemáticas</h4>
                    <p class="card-text">Inicia tu aprendizaje de Matemáticas para preescolar contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>

              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T card  h-100">
                  <div class="inner">
                    <img class="card-img-top" src="img/Preescolar/naturales.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Ciencias Naturales</h4>
                    <p class="card-text">Inicia tu aprendizaje de ciencias naturales para preescolar contenido de
                      ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>

              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T  card h-100">
                  <div class="inner">
                    <img class="card-img-top" src="img/Preescolar/edfisica.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Educación Física</h4>
                    <p class="card-text">Inicia tu aprendizaje de educación física para preescolar contenido de ayúdame
                      en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>



              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">

                <div class="box T card  h-100">
                  <div class="inner">
                    <img class="card-img-top" src="img/Preescolar/religion.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Educación Religiosa </h4>
                    <p class="card-text">Inicia tu aprendizaje de educación religiosa para preescolar contenido de
                      ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>

                  </div>
                </div>
              </div>

              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T card  h-100">
                  <div class="inner">
                    <img class="card-img-top" src="img/Preescolar/ingles.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Inglés</h4>
                    <p class="card-text">Inicia tu aprendizaje de inglés para preescolar contenido de ayúdame en.</p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>


              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T card h-100">
                  <div class="inner">
                    <img class="card-img-top " src="img/Preescolar/etica.png" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Ética y valores</h4>
                    <p class="card-text">Inicia tu aprendizaje de ética y valores para preescolar contenido de ayúdame
                      en.</p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>


              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T card h-100">
                  <div class="inner">
                    <img class="card-img-top  " src="img/Preescolar/artistica.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Educación Artística</h4>
                    <p class="card-text">Inicia tu aprendizaje de educación artística para preescolar contenido de
                      ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>

            </div>


          </div>


          <br>
          <br>

        </div>

        <div class="tab-pane fade " id="pills-primero" role="tabpanel" aria-labelledby="pills-primero-tab">
          <div class="container">

            <div class="xo">

              <h1 class="text-center  "><b>Cursos de Primero 1º<i style="font-size: 38px;"
                    class="ml-3 fas fa-book"></i></b></h1>


              <p class="text-center ">Esperamos que te guste el contenido de primero de primaria de ayúdame en. <i
                  style="font-size:40px;" class="far fa-smile-wink"></i></p>
            </div>


            <br>
            <!-- EMPIEZA MATERIAS DE PRIMERO-->

            <div class=" row text-center f">

              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T  card  h-100 ">
                  <div class="inner">
                    <img class=" card-img-top" src="img/1/sociales1.jpg" width="400px" height="180px">
                  </div>
                  <div class=" card-body">
                    <h4 class="card-title" style="font-weight:bold ;">Ciencias Sociales</h4>
                    <p class="card-text">Inicia tu aprendizaje de ciencias sociales para primero de
                      primaria contenido de ayúdame en.</p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>

              <div class="mouu col-lg-4 col-md-6 col-xl-3 mb-4">
                <div class="box T  card h-100">
                  <div class="inner">
                    <img class="card-img-top" class="rounded-top" src="img/1/español1.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Lengua Castellana</h4>
                    <p class="card-text">Inicia tu aprendizaje de Lengua Castellana y Literatura para
                      primero de primaria contenido de ayúdame en.</p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>

              <div class="mouu col-lg-4 col-md-6 col-xl-3 mb-4">
                <div class="box T card  h-100">
                  <div class="inner">
                    <img class="card-img-top" src="img/1/mate1.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Matemáticas</h4>
                    <p class="card-text">Inicia tu aprendizaje de Matemáticas para primero de primaria
                      contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>

              <div class="mouu col-lg-4 col-md-6 col-xl-3 mb-4">
                <div class="box T  card h-100">
                  <div class="inner">
                    <img class="card-img-top" src="img/1/naturales1.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Ciencias Naturales</h4>
                    <p class="card-text"> Inicia tu aprendizaje de ciencias naturales para primero de
                      primaria contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>



              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">

                <div class="box T card  h-100">
                  <div class="inner">
                    <img class="card-img-top" src="img/1/edfisica1.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Educación Física</h4>
                    <p class="card-text"> Inicia tu aprendizaje de educación física para primero de
                      primaria contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>

                  </div>
                </div>
              </div>

              <div class="mouu col-lg-4 col-md-6 col-xl-3  mb-4">
                <div class="box T card  h-100">
                  <div class="inner">
                    <img class="card-img-top" src="img/1/religion1.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Educación Religiosa</h4>
                    <p class="card-text">
                      Inicia tu aprendizaje de educación religiosa para primero de
                      primaria contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>


              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T card h-100">
                  <div class="inner">
                    <img class="card-img-top " src="img/1/ingles1.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Inglés</h4>
                    <p class="card-text">
                      Inicia tu aprendizaje de inglés para primero de primaria
                      contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>


              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T card h-100">
                  <div class="inner">
                    <img class="card-img-top  " src="img/1/etica1.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Ética y valores</h4>
                    <p class="card-text">
                      Inicia tu aprendizaje de ética y valores para primero de
                      primaria contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>

              <div class="mouu col-lg-4 col-md-6 col-xl-3 mb-4">
                <div class="box T card h-100">
                  <div class="inner">
                    <img class="card-img-top  " src="img/1/artistica1.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Educación Artística</h4>
                    <p class="card-text">
                      Inicia tu aprendizaje de educación artística para primero de
                      primaria contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>

              <div class="mouu col-lg-4 col-md-6 col-xl-3  mb-4">
                <div class="box T card h-100">
                  <div class="inner">
                    <img class="card-img-top  " src="img/1/informatica1.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Informática</h4>
                    <p class="card-text">
                      Inicia tu aprendizaje de informática para primero de primaria
                      contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>

            </div>


          </div>


          <br>
          <br>
        </div>


<!-------------------------------------------------- termina tercer periodo ---------------------------------------->



<!-------------------------------------------------- empieza segundo ---------------------------------------->

        <div class="tab-pane fade" id="pills-segundo" role="tabpanel" aria-labelledby="pills-segundo-tab">

          <div class="container">

            <div class="xo">

              <h1 class="text-center  "><b>Cursos de Tercero 2º<i style="font-size: 38px;"
                    class="ml-3 fas fa-book"></i></b></h1>


              <p class="text-center ">Esperamos que te guste el contenido de segundo de primaria de ayúdame en. <i
                  style="font-size:40px;" class="far fa-smile-wink"></i></p>
            </div>


            <br>
           <!-------------------------------------------------- ---------------------------- ---------------------------------------->

            <div class=" row text-center f">

              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T  card  h-100 ">
                  <div class="inner">
                    <img class=" card-img-top" src="img/2/sociales2.jpg" width="400px" height="180px">
                  </div>
                  <div class=" card-body">
                    <h4 class="card-title" style="font-weight:bold ;">Ciencias Sociales</h4>
                    <p class="card-text">Inicia tu aprendizaje de ciencias sociales para segundo de
                      primaria contenido de ayúdame en.</p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>

              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T  card h-100">
                  <div class="inner">
                    <img class="card-img-top" class="rounded-top" src="img/2/español2.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Lengua Castellana</h4>
                    <p class="card-text">Inicia tu aprendizaje de Lengua Castellana y Literatura para
                      segundo de primaria contenido de ayúdame en.</p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>

              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T card  h-100">
                  <div class="inner">
                    <img class="card-img-top" src="img/2/mate2.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Matemáticas</h4>
                    <p class="card-text">Inicia tu aprendizaje de Matemáticas para segundo de primaria
                      contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>

              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T  card h-100">
                  <div class="inner">
                    <img class="card-img-top" src="img/2/naturales2.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Ciencias Naturales</h4>
                    <p class="card-text"> Inicia tu aprendizaje de ciencias naturales para segundo de
                      primaria contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>



              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">

                <div class="box T card  h-100">
                  <div class="inner">
                    <img class="card-img-top" src="img/2/edfisica2.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Educación Física</h4>
                    <p class="card-text"> Inicia tu aprendizaje de educación física para segundo de
                      primaria contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>

                  </div>
                </div>
              </div>

              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T card  h-100">
                  <div class="inner">
                    <img class="card-img-top" src="img/2/religion2.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Educación Religiosa</h4>
                    <p class="card-text">
                      Inicia tu aprendizaje de educación religiosa para segundo de
                      primaria contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>


              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T card h-100">
                  <div class="inner">
                    <img class="card-img-top " src="img/2/ingles2.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Inglés</h4>
                    <p class="card-text">
                      Inicia tu aprendizaje de inglés para segundo de primaria
                      contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>


              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T card h-100">
                  <div class="inner">
                    <img class="card-img-top  " src="img/2/etica2.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Ética y valores</h4>
                    <p class="card-text">
                      Inicia tu aprendizaje de ética y valores para segundo de
                      primaria contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>

              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T card h-100">
                  <div class="inner">
                    <img class="card-img-top  " src="img/2/artistica2.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Educación Artística</h4>
                    <p class="card-text">
                      Inicia tu aprendizaje de educación artística para segundo de
                      primaria contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>

              <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
                <div class="box T card h-100">
                  <div class="inner">
                    <img class="card-img-top  " src="img/2/informatica2.jpg" width="400px" height="180px">
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">Informática</h4>
                    <p class="card-text">
                      Inicia tu aprendizaje de informática para segundo de primaria
                      contenido de ayúdame en.
                    </p>
                  </div>
                  <div class="card-footer l">
                    <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
                  </div>
                </div>
              </div>


            </div>


          </div>


          <br>
          <br>
        </div>
<!-------------------------------------------------- termina segundo  ---------------------------------------->



<!-------------------------------------------------- empieza tercero  ---------------------------------------->
        <div class="tab-pane fade" id="pills-tercero" role="tabpanel" aria-labelledby="pills-tercero-tab">
          <div class="container">

            <div class="xo">

              <h1 class="text-center  "><b>Cursos de Tercero 3º<i style="font-size: 38px;"
                    class="ml-3 fas fa-book"></i></b></h1>


              <p class="text-center ">Esperamos que te guste el contenido de tercero de primaria de ayúdame en. <i
                  style="font-size:40px;" class="far fa-smile-wink"></i></p>
            </div>


            <br>
           <!------------------------------------------------------------------------------------------------- ---------------------------------------->

      <div class=" row text-center f">

        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T  card  h-100 ">
            <div class="inner">
              <img class=" card-img-top" src="img/3/sociales3.jpg" width="400px" height="180px">
            </div>
            <div class=" card-body">
              <h4 class="card-title" style="font-weight:bold ;">Ciencias Sociales</h4>
              <p class="card-text">Inicia tu aprendizaje de ciencias sociales para tercero de
                primaria contenido de ayúdame en.</p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>

        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T  card h-100">
            <div class="inner">
              <img class="card-img-top" class="rounded-top" src="img/3/español3.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Lengua Castellana</h4>
              <p class="card-text">Inicia tu aprendizaje de Lengua Castellana y Literatura para
                tercero de primaria contenido de ayúdame en.</p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>

        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T card  h-100">
            <div class="inner">
              <img class="card-img-top" src="img/3/mate3.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Matemáticas</h4>
              <p class="card-text">Inicia tu aprendizaje de Matemáticas para tercero de primaria
                contenido de ayúdame en.
              </p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>

        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T  card h-100">
            <div class="inner">
              <img class="card-img-top" src="img/3/naturales3.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Ciencias Naturales</h4>
              <p class="card-text"> Inicia tu aprendizaje de ciencias naturales para tercero de
                primaria contenido de ayúdame en.
              </p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>



        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">

          <div class="box T card  h-100">
            <div class="inner">
              <img class="card-img-top" src="img/3/edfisica3.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Educación Física</h4>
              <p class="card-text"> Inicia tu aprendizaje de educación física para tercero de
                primaria contenido de ayúdame en.
              </p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>

            </div>
          </div>
        </div>

        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T card  h-100">
            <div class="inner">
              <img class="card-img-top" src="img/3/religion3.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Educación Religiosa</h4>
              <p class="card-text">
                Inicia tu aprendizaje de educación religiosa para tercero de
                primaria contenido de ayúdame en.
              </p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>


        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T card h-100">
            <div class="inner">
              <img class="card-img-top " src="img/3/ingles3.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Inglés</h4>
              <p class="card-text">
                Inicia tu aprendizaje de inglés para tercero de primaria
                contenido de ayúdame en.
              </p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>


        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T card h-100">
            <div class="inner">
              <img class="card-img-top  " src="img/3/etica3.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Ética y valores</h4>
              <p class="card-text">
                Inicia tu aprendizaje de ética y valores para tercero de
                primaria contenido de ayúdame en.
              </p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>

        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T card h-100">
            <div class="inner">
              <img class="card-img-top  " src="img/3/artistica3.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Educación Artística</h4>
              <p class="card-text">
                Inicia tu aprendizaje de educación artística para tercero de
                primaria contenido de ayúdame en.
              </p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>

        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T card h-100">
            <div class="inner">
              <img class="card-img-top  " src="img/3/informatica3.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Informática</h4>
              <p class="card-text">
                Inicia tu aprendizaje de informática para tercero de primaria
                contenido de ayúdame en.
              </p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>

            </div>


          </div>


          <br>
          <br>

        </div>
<!-------------------------------------------------- termina tercer  ---------------------------------------->




 <!--------------------------------------------------- empieza cursos cuarto ---------------------------------------->
<div class="tab-pane fade" id="pills-cuarto" role="tabpanel" aria-labelledby="pills-cuarto-tab">
  <div class="container">

    <div class="xo">

      <h1 class="text-center  "><b>Cursos de Cuarto 4º<i style="font-size: 38px;"
            class="ml-3 fas fa-book"></i></b></h1>


      <p class="text-center ">Esperamos que te guste el contenido de cuarto de primaria de ayúdame en. <i
          style="font-size:40px;" class="far fa-smile-wink"></i></p>
    </div>


    <br>
   <!----------------------------------------------------------------------------------------------------->

   <div class=" row text-center f">

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card  h-100 ">
        <div class="inner">
          <img class=" card-img-top" src="img/4/sociales4.jpg" width="400px" height="180px">
        </div>
        <div class=" card-body">
          <h4 class="card-title" style="font-weight:bold ;">Ciencias Sociales</h4>
          <p class="card-text">Inicia tu aprendizaje de ciencias sociales para cuarto de
            primaria contenido de ayúdame en.</p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" class="rounded-top" src="img/4/español4.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Lengua Castellana</h4>
          <p class="card-text">Inicia tu aprendizaje de Lengua Castellana y Literatura para
            cuarto de primaria contenido de ayúdame en.</p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/4/mate4.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Matemáticas</h4>
          <p class="card-text">Inicia tu aprendizaje de Matemáticas para cuarto de primaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

<div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" src="img/4/naturales4.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Ciencias Naturales</h4>
          <p class="card-text"> Inicia tu aprendizaje de ciencias naturales para cuarto de
            primaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>



     <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">

      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/4/edfisica4.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Física</h4>
          <p class="card-text"> Inicia tu aprendizaje de educación física para cuarto de
            primaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>

        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/4/religion4.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Religiosa</h4>
          <p class="card-text">
            Inicia tu aprendizaje de educación religiosa para cuarto de
            primaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top " src="img/4/ingles4.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Inglés</h4>
          <p class="card-text">
            Inicia tu aprendizaje de inglés para cuarto de primaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/4/etica4.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Ética y valores</h4>
          <p class="card-text">
            Inicia tu aprendizaje de ética y valores para cuarto de
            primaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/4/artistica4.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Artística</h4>
          <p class="card-text">
            Inicia tu aprendizaje de educación artística para cuarto de
            primaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/4/informatica4.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Informática</h4>
          <p class="card-text">
            Inicia tu aprendizaje de informática para cuarto de primaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    </div>


  </div>


  <br>
  <br>

</div>
<!---------------------------------------------------  termina cursos cuarto periodo---------------------------------------->






<!--------------------------------------------------- empieza cursos quinto periodo---------------------------------------->
<div class="tab-pane fade" id="pills-quinto" role="tabpanel" aria-labelledby="pills-quinto-tab">
  <div class="container">

    <div class="xo">

      <h1 class="text-center  "><b>Cursos de Quinto 5º<i style="font-size: 38px;"
            class="ml-3 fas fa-book"></i></b></h1>


      <p class="text-center ">Esperamos que te guste el contenido de quinto de primaria de ayúdame en. <i
          style="font-size:40px;" class="far fa-smile-wink"></i></p>
    </div>


    <br>
   <!----------------------------------------------------------------------------------------------------->

   <div class=" row text-center f">

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card  h-100 ">
        <div class="inner">
          <img class=" card-img-top" src="img/5/sociales5.jpg" width="400px" height="180px">
        </div>
        <div class=" card-body">
          <h4 class="card-title" style="font-weight:bold ;">Ciencias Sociales</h4>
          <p class="card-text">Inicia tu aprendizaje de ciencias sociales para quinto de
            primaria contenido de ayúdame en.</p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" class="rounded-top" src="img/5/español5.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Lengua Castellana</h4>
          <p class="card-text">Inicia tu aprendizaje de Lengua Castellana y Literatura para
            quinto de primaria contenido de ayúdame en.</p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/5/mate5.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Matemáticas</h4>
          <p class="card-text">Inicia tu aprendizaje de Matemáticas para quinto de primaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" src="img/5/naturales5.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Ciencias Naturales</h4>
          <p class="card-text"> Inicia tu aprendizaje de ciencias naturales para quinto de
            primaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>



    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">

      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/5/edfisica5.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Física</h4>
          <p class="card-text"> Inicia tu aprendizaje de educación física para quinto de
            primaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>

        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/5/religion5.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Religiosa</h4>
          <p class="card-text">
            Inicia tu aprendizaje de educación religiosa para quinto de
            primaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top " src="img/5/ingles5.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Inglés</h4>
          <p class="card-text">
            Inicia tu aprendizaje de inglés para quinto de primaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/5/etica5.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Ética y valores</h4>
          <p class="card-text">
            Inicia tu aprendizaje de ética y valores para quinto de
            primaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/5/artistica5.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Artística</h4>
          <p class="card-text">
            Inicia tu aprendizaje de educación artística para quinto de
            primaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/5/informatica5.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Informática</h4>
          <p class="card-text">
            Inicia tu aprendizaje de informática para quinto de primaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>



    </div>


  </div>


  <br>
  <br>

</div>
<!---------------------------------------------------  termina cursos quinto periodo---------------------------------------->


<!--------------------------------------------------- empieza cursos sexto periodo---------------------------------------->
<div class="tab-pane fade" id="pills-sexto" role="tabpanel" aria-labelledby="pills-sexto-tab">
  <div class="container">

    <div class="xo">

      <h1 class="text-center  "><b>Cursos de Sexto 6º<i style="font-size: 38px;"
            class="ml-3 fas fa-book"></i></b></h1>


      <p class="text-center ">Esperamos que te guste el contenido de sexto de secundaria de ayúdame en. <i
          style="font-size:40px;" class="far fa-smile-wink"></i></p>
    </div>


    <br>
   <!----------------------------------------------------------------------------------------------------->


   <div class=" row text-center f">

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card  h-100 ">
        <div class="inner">
          <img class=" card-img-top" src="img/6/sociales6.jpg" width="400px" height="180px">
        </div>
        <div class=" card-body">
          <h4 class="card-title" style="font-weight:bold ;">Ciencias Sociales</h4>
          <p class="card-text">Inicia tu aprendizaje de ciencias sociales para sexto de
            secundaria contenido de ayúdame en.</p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" class="rounded-top" src="img/6/español6.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Lengua Castellana</h4>
          <p class="card-text">Inicia tu aprendizaje de Lengua Castellana y Literatura para
            sexto de secundaria contenido de ayúdame en.</p>
        </div>
        <div class="card-footer l">
          <a href="curso_de_español6.html" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/6/mate6.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Matemáticas</h4>
          <p class="card-text">Inicia tu aprendizaje de Matemáticas para sexto de secundaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" src="img/6/naturales6.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Ciencias Naturales</h4>
          <p class="card-text"> Inicia tu aprendizaje de ciencias naturales para sexto de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>



    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">

      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/6/edfisica6.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Física</h4>
          <p class="card-text"> Inicia tu aprendizaje de educación física para sexto de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>

        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/6/religion6.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Religiosa</h4>
          <p class="card-text">
            Inicia tu aprendizaje de educación religiosa para sexto de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top " src="img/6/ingles6.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Inglés</h4>
          <p class="card-text">
            Inicia tu aprendizaje de inglés para sexto de secundaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/6/etica6.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Ética y valores</h4>
          <p class="card-text">
            Inicia tu aprendizaje de ética y valores para sexto de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/6/artistica6.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Artística</h4>
          <p class="card-text">
            Inicia tu aprendizaje de educación artística para sexto de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/6/informatica6.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Informática</h4>
          <p class="card-text">
            Inicia tu aprendizaje de informática para sexto de secundaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>



    </div>


  </div>


  <br>
  <br>

</div>
<!---------------------------------------------------  termina cursos sexto periodo---------------------------------------->



<!--------------------------------------------------- empieza cursos septimo periodo---------------------------------------->
<div class="tab-pane fade" id="pills-septimo" role="tabpanel" aria-labelledby="pills-septimo-tab">
  <div class="container">

    <div class="xo">

      <h1 class="text-center  "><b>Cursos de Séptimo 7º<i style="font-size: 38px;"
            class="ml-3 fas fa-book"></i></b></h1>


      <p class="text-center ">Esperamos que te guste el contenido de séptimo de secundaria de ayúdame en. <i
          style="font-size:40px;" class="far fa-smile-wink"></i></p>
    </div>


    <br>
   <!----------------------------------------------------------------------------------------------------->


   <div class=" row text-center f">

        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T  card  h-100 ">
            <div class="inner">
              <img class=" card-img-top" src="img/7/sociales7.jpg" width="400px" height="180px">
            </div>
            <div class=" card-body">
              <h4 class="card-title" style="font-weight:bold ;">Ciencias Sociales</h4>
              <p class="card-text">Inicia tu aprendizaje de ciencias sociales para séptimo de
                secundaria contenido de ayúdame en.</p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>

        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T  card h-100">
            <div class="inner">
              <img class="card-img-top" class="rounded-top" src="img/7/español7.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Lengua Castellana</h4>
              <p class="card-text">Inicia tu aprendizaje de Lengua Castellana y Literatura para
                séptimo de secundaria contenido de ayúdame en.</p>
            </div>
            <div class="card-footer l">
              <a href="curso_de_español6.html" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>

        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T card  h-100">
            <div class="inner">
              <img class="card-img-top" src="img/7/mate7.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Matemáticas</h4>
              <p class="card-text">Inicia tu aprendizaje de Matemáticas para séptimo de secundaria
                contenido de ayúdame en.
              </p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>

        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T  card h-100">
            <div class="inner">
              <img class="card-img-top" src="img/7/naturales7.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Ciencias Naturales</h4>
              <p class="card-text"> Inicia tu aprendizaje de ciencias naturales para séptimo de
                secundaria contenido de ayúdame en.
              </p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>



        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T card  h-100">
            <div class="inner">
              <img class="card-img-top" src="img/7/edfisica7.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Educación Física</h4>
              <p class="card-text"> Inicia tu aprendizaje de educación física para séptimo de
                secundaria contenido de ayúdame en.
              </p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>

            </div>
          </div>
        </div>

        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T card  h-100">
            <div class="inner">
              <img class="card-img-top" src="img/7/religion7.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Educación Religiosa</h4>
              <p class="card-text">
                Inicia tu aprendizaje de educación religiosa para séptimo de
                secundaria contenido de ayúdame en.
              </p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>


        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T card h-100">
            <div class="inner">
              <img class="card-img-top " src="img/7/ingles7.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Inglés</h4>
              <p class="card-text">
                Inicia tu aprendizaje de inglés para séptimo de secundaria
                contenido de ayúdame en.
              </p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>


        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T card h-100">
            <div class="inner">
              <img class="card-img-top  " src="img/7/etica7.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Ética y valores</h4>
              <p class="card-text">
                Inicia tu aprendizaje de ética y valores para séptimo de
                secundaria contenido de ayúdame en.
              </p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>

        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T card h-100">
            <div class="inner">
              <img class="card-img-top  " src="img/7/artistica7.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Educación Artística</h4>
              <p class="card-text">
                Inicia tu aprendizaje de educación artística para séptimo de
                secundaria contenido de ayúdame en.
              </p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>

        <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
          <div class="box T card h-100">
            <div class="inner">
              <img class="card-img-top  " src="img/7/informatica7.jpg" width="400px" height="180px">
            </div>
            <div class="card-body">
              <h4 class="card-title">Informática</h4>
              <p class="card-text">
                Inicia tu aprendizaje de informática para séptimo de secundaria
                contenido de ayúdame en.
              </p>
            </div>
            <div class="card-footer l">
              <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
            </div>
          </div>
        </div>

    </div>


  </div>


  <br>
  <br>

</div>
<!---------------------------------------------------  termina cursos septimo periodo---------------------------------------->


<!--------------------------------------------------- empieza cursos octavo periodo---------------------------------------->
<div class="tab-pane fade" id="pills-octavo" role="tabpanel" aria-labelledby="pills-octavo-tab">
  <div class="container">

    <div class="xo">

      <h1 class="text-center  "><b>Cursos de Octavo 8º<i style="font-size: 38px;"
            class="ml-3 fas fa-book"></i></b></h1>


      <p class="text-center ">Esperamos que te guste el contenido de octavo de secundaria de ayúdame en. <i
          style="font-size:40px;" class="far fa-smile-wink"></i></p>
    </div>


    <br>
   <!----------------------------------------------------------------------------------------------------->


   <div class=" row text-center f">

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card  h-100 ">
        <div class="inner">
          <img class=" card-img-top" src="img/8/sociales8.jpg" width="400px" height="180px">
        </div>
        <div class=" card-body">
          <h4 class="card-title" style="font-weight:bold ;">Ciencias Sociales</h4>
          <p class="card-text">Inicia tu aprendizaje de ciencias sociales para octavo de
            secundaria contenido de ayúdame en.</p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" class="rounded-top" src="img/8/español8.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Lengua Castellana</h4>
          <p class="card-text">Inicia tu aprendizaje de Lengua Castellana y Literatura para
            octavo de secundaria contenido de ayúdame en.</p>
        </div>
        <div class="card-footer l">
          <a href="curso_de_español6.html" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/8/mate8.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Matemáticas</h4>
          <p class="card-text">Inicia tu aprendizaje de Matemáticas para octavo de secundaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" src="img/8/naturales8.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Ciencias Naturales</h4>
          <p class="card-text"> Inicia tu aprendizaje de ciencias naturales para octavo de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>



    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">

      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/8/edfisica8.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Física</h4>
          <p class="card-text"> Inicia tu aprendizaje de educación física para octavo de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>

        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/8/religion8.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Religiosa</h4>
          <p class="card-text">
            Inicia tu aprendizaje de educación religiosa para octavo de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top " src="img/8/ingles8.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Inglés</h4>
          <p class="card-text">
            Inicia tu aprendizaje de inglés para octavo de secundaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/8/etica8.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Ética y valores</h4>
          <p class="card-text">
            Inicia tu aprendizaje de ética y valores para octavo de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/8/artistica8.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Artística</h4>
          <p class="card-text">
            Inicia tu aprendizaje de educación artística para octavo de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/8/informatica8.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Informática</h4>
          <p class="card-text">
            Inicia tu aprendizaje de informática para octavo de secundaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    </div>


  </div>


  <br>
  <br>

</div>
<!---------------------------------------------------  termina cursos octavo periodo---------------------------------------->


<!--------------------------------------------------- empieza cursos noveno periodo---------------------------------------->
<div class="tab-pane fade" id="pills-noveno" role="tabpanel" aria-labelledby="pills-noveno-tab">
  <div class="container">

    <div class="xo">

      <h1 class="text-center  "><b>Cursos de Noveno 9º<i style="font-size: 38px;"
            class="ml-3 fas fa-book"></i></b></h1>


      <p class="text-center ">Esperamos que te guste el contenido de noveno de secundaria de ayúdame en. <i
          style="font-size:40px;" class="far fa-smile-wink"></i></p>
    </div>


    <br>
   <!----------------------------------------------------------------------------------------------------->


   <div class=" row text-center f">

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card  h-100 ">
        <div class="inner">
          <img class=" card-img-top" src="img/9/sociales9.jpg" width="400px" height="180px">
        </div>
        <div class=" card-body">
          <h4 class="card-title" style="font-weight:bold ;">Ciencias Sociales</h4>
          <p class="card-text">Inicia tu aprendizaje de ciencias sociales para noveno de
            secundaria contenido de ayúdame en.</p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" class="rounded-top" src="img/9/español9.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Lengua Castellana</h4>
          <p class="card-text">Inicia tu aprendizaje de Lengua Castellana y Literatura para
            noveno de secundaria contenido de ayúdame en.</p>
        </div>
        <div class="card-footer l">
          <a href="curso_de_español6.html" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/9/mate9.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Matemáticas</h4>
          <p class="card-text">Inicia tu aprendizaje de Matemáticas para noveno de secundaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" src="img/9/naturales9.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Ciencias Naturales</h4>
          <p class="card-text"> Inicia tu aprendizaje de ciencias naturales para noveno de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>



    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/9/edfisica9.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Física</h4>
          <p class="card-text"> Inicia tu aprendizaje de educación física para noveno de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>

        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/9/religion9.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Religiosa</h4>
          <p class="card-text">
            Inicia tu aprendizaje de educación religiosa para noveno de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top " src="img/9/ingles9.png" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Inglés</h4>
          <p class="card-text">
            Inicia tu aprendizaje de inglés para noveno de secundaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/9/etica9.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Ética y valores</h4>
          <p class="card-text">
            Inicia tu aprendizaje de ética y valores para noveno de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/9/artistica9.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Artística</h4>
          <p class="card-text">
            Inicia tu aprendizaje de educación artística para noveno de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/9/informatica9.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Informática</h4>
          <p class="card-text">
            Inicia tu aprendizaje de informática para noveno de secundaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/9/economicas9.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">C.Económicas</h4>
          <p class="card-text">
            Inicia tu aprendizaje de ciencias económicas para noveno de secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/9/filosofia9.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title"> Filosofía</h4>
          <p class="card-text">
           
Inicia tu aprendizaje de filosofía para noveno de secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/9/quimica9.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Química</h4>
          <p class="card-text">
        
Inicia tu aprendizaje de química para noveno de secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/9/fisica9.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title"> Física</h4>
          <p class="card-text">
           
Inicia tu aprendizaje de física para noveno de secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    </div>


  </div>


  <br>
  <br>

</div>
<!---------------------------------------------------  termina cursos noveno periodo---------------------------------------->



<!--------------------------------------------------- empieza cursos decimo periodo---------------------------------------->
<div class="tab-pane fade" id="pills-decimo" role="tabpanel" aria-labelledby="pills-decimo-tab">
  <div class="container">

    <div class="xo">

      <h1 class="text-center  "><b>Cursos de Décimo 10º<i style="font-size: 38px;"
            class="ml-3 fas fa-book"></i></b></h1>


      <p class="text-center ">Esperamos que te guste el contenido de décimo de secundaria de ayúdame en. <i
          style="font-size:40px;" class="far fa-smile-wink"></i></p>
    </div>


    <br>
   <!----------------------------------------------------------------------------------------------------->

   <div class=" row text-center f">

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card  h-100 ">
        <div class="inner">
          <img class=" card-img-top" src="img/10/sociales10.jpg" width="400px" height="180px">
        </div>
        <div class=" card-body">
          <h4 class="card-title" style="font-weight:bold ;">Ciencias Sociales</h4>
          <p class="card-text">Inicia tu aprendizaje de ciencias sociales para décimo de
            secundaria contenido de ayúdame en.</p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" class="rounded-top" src="img/10/español10.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Lengua Castellana</h4>
          <p class="card-text">Inicia tu aprendizaje de Lengua Castellana y Literatura para
            décimo de secundaria contenido de ayúdame en.</p>
        </div>
        <div class="card-footer l">
          <a href="curso_de_español6.html" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/10/mate10.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Matemáticas</h4>
          <p class="card-text">Inicia tu aprendizaje de Matemáticas para décimo de secundaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" src="img/10/naturales10.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Ciencias Naturales</h4>
          <p class="card-text"> Inicia tu aprendizaje de ciencias naturales para décimo de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>



    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">

      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/10/edfisica10.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Física</h4>
          <p class="card-text"> Inicia tu aprendizaje de educación física para décimo de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>

        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/10/religion10.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Religiosa</h4>
          <p class="card-text">
            Inicia tu aprendizaje de educación religiosa para décimo de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top " src="img/10/ingles10.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Inglés</h4>
          <p class="card-text">
            Inicia tu aprendizaje de inglés para décimo de secundaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/10/etica10.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Ética y valores</h4>
          <p class="card-text">
            Inicia tu aprendizaje de ética y valores para décimo de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/10/artistica10.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Artística</h4>
          <p class="card-text">
            Inicia tu aprendizaje de educación artística para décimo de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/10/informatica10.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Informática</h4>
          <p class="card-text">
            Inicia tu aprendizaje de informática para décimo de secundaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/10/economicas10.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">C.Económicas</h4>
          <p class="card-text">
            Inicia tu aprendizaje de ciencias económicas para décimo de secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/10/filosofia10.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title"> Filosofía</h4>
          <p class="card-text">
           
Inicia tu aprendizaje de filosofía para décimo de secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/10/quimica10.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Química</h4>
          <p class="card-text">
        
Inicia tu aprendizaje de química para décimo de secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/10/fisica10.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title"> Física</h4>
          <p class="card-text">
           
Inicia tu aprendizaje de física para décimo de secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    </div>


  </div>


  <br>
  <br>

</div>
<!---------------------------------------------------  termina cursos decimo periodo---------------------------------------->



<!--------------------------------------------------- empieza cursos undecimo periodo---------------------------------------->
<div class="tab-pane fade" id="pills-undecimo" role="tabpanel" aria-labelledby="pills-undecimo-tab">
  <div class="container">

    <div class="xo">

      <h1 class="text-center  "><b>Cursos de Undécimo 11º<i style="font-size: 38px;"
            class="ml-3 fas fa-book"></i></b></h1>


      <p class="text-center ">Esperamos que te guste el contenido de undécimo de secundaria de ayúdame en. <i
          style="font-size:40px;" class="far fa-smile-wink"></i></p>
    </div>


    <br>
   <!----------------------------------------------------------------------------------------------------->

   <div class=" row text-center f">

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card  h-100 ">
        <div class="inner">
          <img class=" card-img-top" src="img/11/sociales11.jpg" width="400px" height="180px">
        </div>
        <div class=" card-body">
          <h4 class="card-title" style="font-weight:bold ;">Ciencias Sociales</h4>
          <p class="card-text">Inicia tu aprendizaje de ciencias sociales para undécimo de
            secundaria contenido de ayúdame en.</p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" class="rounded-top" src="img/11/español11.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Lengua Castellana</h4>
          <p class="card-text">Inicia tu aprendizaje de Lengua Castellana y Literatura para
            undécimo de secundaria contenido de ayúdame en.</p>
        </div>
        <div class="card-footer l">
          <a href="curso_de_español6.html" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/11/mate11.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Matemáticas</h4>
          <p class="card-text">Inicia tu aprendizaje de Matemáticas para undécimo de secundaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" src="img/11/naturales11.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Ciencias Naturales</h4>
          <p class="card-text"> Inicia tu aprendizaje de ciencias naturales para undécimo de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>



    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">

      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/11/edfisica11.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Física</h4>
          <p class="card-text"> Inicia tu aprendizaje de educación física para undécimo de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>

        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/11/religion11.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Religiosa</h4>
          <p class="card-text">
            Inicia tu aprendizaje de educación religiosa para undécimo de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top " src="img/11/ingles11.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Inglés</h4>
          <p class="card-text">
            Inicia tu aprendizaje de inglés para undécimo de secundaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>



    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/11/etica11.png" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Ética y valores</h4>
          <p class="card-text">
            Inicia tu aprendizaje de ética y valores para undécimo de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/11/artistica11.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Educación Artística</h4>
          <p class="card-text">
            Inicia tu aprendizaje de educación artística para undécimo de
            secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/11/informatica11.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Informática</h4>
          <p class="card-text">
            Inicia tu aprendizaje de informática para undécimo de secundaria
            contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/11/economicas11.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">C.Económicas</h4>
          <p class="card-text">
            Inicia tu aprendizaje de ciencias económicas para undécimo de secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/11/filosofia11.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title"> Filosofía</h4>
          <p class="card-text">
           
Inicia tu aprendizaje de filosofía para undécimo de secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/11/quimica11.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Química</h4>
          <p class="card-text">
        
Inicia tu aprendizaje de química para undécimo de secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card h-100">
        <div class="inner">
          <img class="card-img-top  " src="img/11/fisica11.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title"> Física</h4>
          <p class="card-text">
           
Inicia tu aprendizaje de física para undécimo de secundaria contenido de ayúdame en.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    </div>


  </div>


  <br>
  <br>

</div>
<!---------------------------------------------------  termina cursos undecimo periodo---------------------------------------->








<!--------------------------------------------------- empieza cursos de software ---------------------------------------->
<div class="tab-pane fade" id="pills-software" role="tabpanel" aria-labelledby="pills-software-tab">
  <div class="container">

    <div class="xo">

      <h1 class="text-center  "><b><i  class="fas fa-laptop-code ml-3"></i>Cursos de Desarrollo de Software<i style="font-size: 38px;" class="ml-3 fas fa-book"></i></b></h1>


      <p class="text-center ">Esperamos que te guste el contenido de la media técnica de desarrollo de software de ayúdame en. <i
          style="font-size:40px;" class="far fa-smile-wink"></i></p>
    </div>


    <br>
   <!----------------------------------------------------------------------------------------------------->

   <div class=" row text-center f">

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card  h-100 ">
        <div class="inner">
          <img class=" card-img-top" src="img/software/1.jpg" width="400px" height="180px">
        </div>
        <div class=" card-body">
          <h4 class="card-title" style="font-weight:bold ;">Introducción a la Programación</h4>
          <p class="card-text">Inicia tu aprendizaje de introducción a la programación para la media tecnica de desarrollo de software.</p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" class="rounded-top" src="img/software/2.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">HTML</h4>
          <p class="card-text"> Inicia tu aprendizaje de Html para la media tecnica de desarrollo de software.</p>
        </div>
        <div class="card-footer l">
          <a href="curso_de_español6.html" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/software/3.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">CSS</h4>
          <p class="card-text"> Inicia tu aprendizaje de css para la media técnica de desarrollo de software.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" src="img/software/4.png" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">JAVASCRIPT</h4>
          <p class="card-text">Inicia tu aprendizaje de javascript para la media técnica de desarrollo de software.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" src="img/software/5.JPG" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">PHP</h4>
          <p class="card-text">Inicia tu aprendizaje de PHP para la media técnica de desarrollo de software.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

   
    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" src="img/software/5.png" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">SQL</h4>
          <p class="card-text"> Inicia tu aprendizaje de SQL para la media técnica de desarrollo de software.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" src="img/software/6.JPG" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">PYTHON</h4>
          <p class="card-text">Inicia tu aprendizaje de PYTHON para la media técnica de desarrollo de software.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" src="img/software/7.JPG" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">JAVA</h4>
          <p class="card-text">Inicia tu aprendizaje de JAVA para la media técnica de desarrollo de software.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    </div>


  </div>


  <br>
  <br>

</div>
<!---------------------------------------------------  termina cursos de software ---------------------------------------->










<!--------------------------------------------------- empieza cursos de preprensa ---------------------------------------->
<div class="tab-pane fade" id="pills-preprensa" role="tabpanel" aria-labelledby="pills-preprensa-tab">
  <div class="container">

    <div class="xo">

      <h1 class="text-center  "><b><i  class="fas fa-paint-brush ml-3"></i>Cursos de Preprensa<i style="font-size: 38px;" class="ml-3 fas fa-book"></i></b></h1>


      <p class="text-center ">Esperamos que te guste el contenido de la media técnica de Preprensa de  ayúdame en. <i
          style="font-size:40px;" class="far fa-smile-wink"></i></p>
    </div>


    <br>
   <!----------------------------------------------------------------------------------------------------->

   <div class=" row text-center f">

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card  h-100 ">
        <div class="inner">
          <img class=" card-img-top" src="img/preprensa/preprensa.png" width="400px" height="180px">
        </div>
        <div class=" card-body">
          <h4 class="card-title" style="font-weight:bold ;">Introducción a preprensa</h4>
          <p class="card-text">
          
            Inicia tu aprendizaje de introducción a preprensa para la media técnica de preprensa.</p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" class="rounded-top" src="img/preprensa/dibujo.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Dibujo</h4>
          <p class="card-text">

Inicia tu aprendizaje de dibujo para la media técnica de preprensa.</p>
        </div>
        <div class="card-footer l">
          <a href="curso_de_español6.html" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/preprensa/dibujodigital.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Dibujo digital</h4>
          <p class="card-text">
       
Inicia tu aprendizaje de dibujo digital para la media técnica de preprensa.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" src="img/preprensa/diseñografico.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Diseño gráfico</h4>
          <p class="card-text">
       
Inicia tu aprendizaje de introducción a preprensa para la media técnica de preprensa.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>


    </div>


  </div>


  <br>
  <br>

</div>
<!---------------------------------------------------  termina cursos de preprensa ---------------------------------------->



<!--------------------------------------------------- empieza cursos de humanos ---------------------------------------->
<div class="tab-pane fade" id="pills-humanos" role="tabpanel" aria-labelledby="pills-humanos-tab">
  <div class="container">

    <div class="xo">

      <h1 class="text-center  "><b><i class="fas fa-user-tie ml-2"></i>Cursos de Recursos Humanos<i style="font-size: 38px;" class="ml-3 fas fa-book"></i></b></h1>


      <p class="text-center "> Esperamos que te guste el contenido de la media técnica de recursos humanos de ayúdame en. <i
          style="font-size:40px;" class="far fa-smile-wink"></i></p>
    </div>


    <br>
   <!----------------------------------------------------------------------------------------------------->

   <div class=" row text-center f">

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card  h-100 ">
        <div class="inner">
          <img class=" card-img-top" src="img/recursos/1.jpg" width="400px" height="180px">
        </div>
        <div class=" card-body">
          <h4 class="card-title" style="font-weight:bold ;">Introducción a recursos humanos</h4>
          <p class="card-text">
            Inicia tu aprendizaje de introducción a recursos humanos para la media técnica de recursos humanos.</p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" class="rounded-top" src="img/recursos/2.gif" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Administración de Empresas</h4>
          <p class="card-text">
            Inicia tu aprendizaje de Administración de Empresas para la media técnica de recursos humanos.</p>
        </div>
        <div class="card-footer l">
          <a href="curso_de_español6.html" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T card  h-100">
        <div class="inner">
          <img class="card-img-top" src="img/recursos/3.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Elección de empleados</h4>
          <p class="card-text">
            Inicia tu aprendizaje de elección de personal empresarial para la media técnica de recursos humanos.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    <div class="mouu col-lg-4 col-md-6  col-xl-3 mb-4">
      <div class="box T  card h-100">
        <div class="inner">
          <img class="card-img-top" src="img/recursos/4.jpg" width="400px" height="180px">
        </div>
        <div class="card-body">
          <h4 class="card-title">Manejo del personal empresarial</h4>
          <p class="card-text">
            Inicia tu aprendizaje de curso de manejo del personal empresarial para la media técnica de recursos humanos.
          </p>
        </div>
        <div class="card-footer l">
          <a href="#" class="btn btn-success a"><i class="fas fa-book mr-1"></i>Entrar </a>
        </div>
      </div>
    </div>

    </div>


  </div>


  <br>
  <br>

</div>
<!---------------------------------------------------  termina cursos de recursos humanos ---------------------------------------->

      </div>
  </div>



<br>
<br>

  <!-- empieza footer -->

 
  <footer>

<div style="border-top:47px solid #121212; " class="b">

  <div class="container">


    <div class="row py-3 d-flex align-items-center">


      <div style="margin-top: -23px;" class="col-md-6 col-lg-6 text-center text-md-left  "><br>
        <h5 style="font-size: 26px;" style="font-weight: bold;" class="mb-0">
          <i style="font-size: 35px;" class="mr-1 fas fa-laugh-beam"></i> SIGUENOS EN NUESTRAS REDES SOCIALES! </h5>
      </div>


      <div style="margin-top: -16px;" class="  col-md-6 col-lg-6 text-center text-md-right">

        <br>


        <li class="list-inline-item"><a href="https://www.facebook.com/ayudameen.proyecayuda.3"
            class="social-link"><i class=" fab fa-facebook-f"></i></a></li>
        <li class="list-inline-item"><a href="https://twitter.com/AYUDAMEEN1" class="social-link"><i
              class="fab  fa-twitter"></i></a></li>
        <li class="list-inline-item"><a href="https://www.instagram.com/ayuda_me_en/" class="social-link"><i
              class="fab fa-instagram"></i></a></li>

      </div>
    </div>
  </div>
</div>

<div class="container text-center text-md-left mt-5">

  <div class="row mt-3">


    <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">


      <h6 style="font-size: 19px;" class="text-uppercase font-weight-bold "><i class="mr-1 fas fa-info-circle"></i>


        <style>



        </style>

        Información de Ayúdame en
      </h6>
      <hr class="color accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 230px; ">
      <p style="font-size: 20px;">Ayúdame en desarrollado con el fin de proporcionar ayudas de tipo académicas
        mediante cursos virtuales y también mediante nuestro foro donde sera una comunidad donde se compartirá el
        conocimiento. Ayúdame en Aqui encontraras todo lo que necesites.</p>

    </div>

    <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">


      <h6 style="font-size: 19px;" class="text-uppercase font-weight-bold"><i class="mr-1 fas fa-link"></i>Enlaces
        Rapidos</h6>
      <hr class="color accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 130px;">
      <p>
        <a style="font-size: 22px;" href="index.html">Inicio</a>
      </p>
      <p>
        <a style="font-size: 22px;" href="Contáctenos.html">Contáctenos</a>
      </p>
      <p>
        <a style="font-size: 22px;" href="Iniciar_sesion.php">Iniciar Sesión </a>
      </p>
      <p>
        <a style="font-size: 22px;" href="Registro.php">Regístrate</a>
      </p>

    </div>



    <div style="margin-top: 18px;" class=" col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
      <h6 style="font-size:20px;" class="text-uppercase font-weight-bold"><i
          class="fas fa-phone-alt mr-1"></i>ContÁctenos</h6>



      <hr class="color accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 230px; ">
      <p class="z">
        <i class="fas fa-home "></i> Col, Antioquia, medellin</p>
      <p class="z">
        <i class="fas fa-envelope "></i> ayudameen.20@outlook.es</p>
      <p class="z">
        <i class="fas fa-phone "></i> 3004687642</p>



    </div>
  </div>
</div>

</div>

<div class="footer-copyright text-center py-3"><i class="far fa-copyright mr-1"></i>
  2020 AYÚDAME EN - Todos los derechos reservados. contenido recopilado de diferentes fuentes de Información.
</div>


</footer>


<!-- termina footer -->

 
<script src="js/jquery-3.4.1.slim.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>

</html>