<?php

$coneccion= mysqli_connect("127.0.0.1","root","","ayudame_en");
$consultar_usuario_en_bd=mysqli_query($coneccion,"SELECT nivel, grado FROM nivel_estudiante ne join registro r on r.id = ne.idEstudiante where r.usuario = '$_GET[usuario]'");

$i=0;
while($dato_uno_por_uno=mysqli_fetch_array($consultar_usuario_en_bd)){
    $nivel[$i]=$dato_uno_por_uno['nivel'];
    $grado[$i]=$dato_uno_por_uno['grado'];
    $i++;
}

switch($nivel[0]){
    case 1:
        $n = "Primaria";
        break;
    case 2:
        $n = "Secundaria";
        break;
}
switch($nivel[1]){
    case 3:
        $nmt = "Media Técnica Desarrollo de software";
        break;
    case 4:
        $nmt = "Media Técnica Recursos Humanos";
        break;
    case 5:
        $nmt = "Media Técnica Pre Prensa";
        break;
    }
echo "


<!--navbar de estudiante-->

<nav  class='navbar navbar-expand-xl bg-dark navbar-dark fixed-top'>
    <a href='index.php' class='zoom navbar-brand '><img src='img/logo1.png' width='110' height='89'></a>

    <button class='navbar-toggler ' type='button' data-toggle='collapse' data-target='#uno'>
      <span class='navbar-toggler-icon'></span>
    </button>


    <div class='collapse navbar-collapse' id='uno'>

      <ul class='navbar-nav mr-auto  '>
        <li  class='nav-item dropdown mr-1'>
          <a href='' class='su nav-link dropdown-toggle ' data-toggle='dropdown'>
            <i class='fas fa-baby mr-1'></i>$n </a>
          <div  class='dropdown-menu'>
            <a href='$n.html' class='dropdown-item'>$n<i class='fas fa-apple-alt ml-2'></i></a>
            <a href='$grado[0].html' class='dropdown-item'>$grado[0]</a>
          </div>
        </li>";
if(isset($nivel[1])){
    echo "
        <li  class='nav-item dropdown mr-1'>
            <a href='' class='su nav-link dropdown-toggle ' data-toggle='dropdown'>
             <i class='fas fa-baby mr-1'></i>$nmt </a>
            <div  class='dropdown-menu'>
                <a href='$n.html' class='dropdown-item'>$nmt<i class='fas fa-apple-alt ml-2'></i></a>
                <a href='$grado[1].html' class='dropdown-item'>$grado[1]</a>
            </div>
        </li>";

}

 echo "
      </ul>

      <li   class=' nav-item dropdown list-inline-item mr-5' ><a class='nav-link dropdown-toggle usuario mr-3' data-toggle='dropdown' style='font-size:27px;color:#fff; font-weight:bold ;' href=''>  <?php echo $_GET[usuario]; ?><i style='font-size:30px;' class=' ml-2 fas fa-user-circle'></i></a>

<div class='dropdown-menu'>
<a  style='font-size:21px;' href='perfil.html' class='dropdown-item'><b> Perfil<i  class='fas fa-user-alt ml-2'></i></b></a>
   <a style='font-size:21px;' href='cerrar_sesion.php' class='dropdown-item'><b>Cerrar  Sesión<i class='fas fa-power-off ml-2'></i></b></a>


 </div>
</li>


      </div>
    </div>

  </nav>
";


?>