<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/Regístrate.css">

  <link rel="stylesheet" href="css/footer.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/all.css">
  <link rel="stylesheet" href="css/redes_sociales.css">
  <link href="https://fonts.googleapis.com/css?family=Titillium+Web:400,600" rel="stylesheet">
  <style>
    a {
      -webkit-transform: scale(1, 1);
      -webkit-transition-timing-function: ease-out;
      -webkit-transition-duration: 250ms;
      -moz-transform: scale(1, 1);
      -moz-transition-timing-function: ease-out;
      -moz-transition-duration: 250ms;
    }

    a:hover {
      -webkit-transform: scale(1.10, 1.10);
      -webkit-transition-timing-function: ease-out;
      -webkit-transition-duration: 170ms;
      -moz-transform: scale(1.10, 1.10);
      -moz-transition-timing-function: ease-out;
      -moz-transition-duration: 170ms;
    }

    .btn-block {
      -webkit-transform: scale(1, 1);
      -webkit-transition-timing-function: ease-out;
      -webkit-transition-duration: 250ms;
      -moz-transform: scale(1, 1);
      -moz-transition-timing-function: ease-out;
      -moz-transition-duration: 250ms;
    }

    .btn-block:hover {
      -webkit-transform: scale(1.10, 1.10);
      -webkit-transition-timing-function: ease-out;
      -webkit-transition-duration: 170ms;
      -moz-transform: scale(1.10, 1.10);
      -moz-transition-timing-function: ease-out;
      -moz-transition-duration: 170ms;
    }




    .formulario {

      padding: 20px !important;
      background-image: url(../AYUDAME_EN/img/login.jpg) !important;
      color: white !important;

    }

    .form-control {
      background: rgba(0, 0, 0, 0.924) !important;
      border-style: none;
      transition: 0.3s ease-in;
      outline: none;
      border: 1px solid rgb(255, 255, 255) !important;
    }



    .form-control:focus {

      color: white !important;
      border: 1px solid rgb(255, 255, 255) !important;

    }

    /* termina el css de los colores del iniciar sesion y transiciones */





    /* empieza el css para hacer que las letras y el iniciar sesion esten correctamente organizados */
    .form-label-group {
      text-align: left;
      position: relative;
      margin-bottom: 1rem;
      font-family: 'Titillium Web', sans-serif !important;
      font-size: 20px;
    }

    /* termina el css para hacer que las letras y el iniciar sesion esten correctamente organizados */




    /* empieza el css de los contenedores donde iran cada campo del iniciar sesion */
    .form-label-group>input,
    .form-label-group>label {
      padding: .75rem;

    }

    /* termina el css de los contenedores donde iran cada campo del iniciar sesion */




    /* empieza el css de los campos para que sus bordes esten  redondeados y su tamaño */
    .form-label-group input {
      height: auto;
      border-radius: 0.5rem;

    }

    /* termina el css de los campos para que sus bordes esten redondeados y su tamaño */




    /* empieza el css de como iran ubicados las letras de los campos y tambien la transicion */
    .form-label-group>label {
      position: absolute;
      top: 0;
      width: 100%;
      line-height: 1.5;
      pointer-events: none;
      border: 1px solid transparent;
      transition: all 0.2s;

    }

    /* termina el css de como iran ubicados las letras de los campos y tambien la transicion */



    /*  empieza el css de las letras del color y el relleno que iran dentro de los campos*/
    .form-label-group input::placeholder {
      color: transparent;
    }

    .form-label-group input:not(:placeholder-shown) {
      padding-top: 1.25rem;
      padding-bottom: .25rem;

    }

    /*  termina el css de las letras del color y el relleno que iran dentro de los campos*/



    /* empieza el css de las letras cuando se hacen pequeñas en la transicion */
    .form-label-group input:not(:placeholder-shown)~label {
      padding-top: .25rem;
      padding-bottom: .25rem;
      font-size: 15px;
      color: #777!important;
    }

    /* termina el css de las letras cuando se hacen pequeñas en la transicion */





    .wos {
      font-size: 26px;
      color: #ffffff;
      border-radius: 15px;
      padding: 43px;
      background: rgba(0, 0, 0, 0.8);
      border: 2px solid rgb(255, 255, 255);
      transition: all 0.3s;
    }

    .wos:hover {

      background: rgba(0, 0, 0, 0.9);
      border: 2px solid #2fb64e;
      box-shadow: 0 2px 10px #2ba8486e;
    }

    .morlum {
      border: 2px solid rgb(255, 255, 255);
      background: rgba(0, 0, 0, 0.7);
      padding: 20px;
      border-radius: 1rem;
      padding: 40px;
      margin-top: 10px;
      transition: all 0.3s;
    }

    .morlum:hover {
      border: 2px solid #2fb64e;
      box-shadow: 0 2px 10px #2ba8486e;
      background: rgba(0, 0, 0, 0.8);
      padding: 20px;
      border-radius: 1rem;
      padding: 40px;
      margin-top: 10px;
    }

    body {
      color: white;
      font-family: 'Titillium Web', sans-serif !important;
    }
  </style>





  <title>AYÚDAME EN</title>

</head>

<body>
















  <script>


    function validar_los_campos_vacios_registro() {




      tipo_de_usuario = document.getElementById("tipo_de_usuario").value;
      if (tipo_de_usuario == "0") {
        alert("Debes ingresar tu tipo de usuario");
      }



      genero = document.getElementById("genero").value;
      if (genero == "0") {
        alert("Debes ingresar tu tipo de genero");
      }
    }
  </script>

  <!--------------------------------- empieza el registro ------------------------------------>

  <form method="POST" action="src/guardar_grados.php">



    </style>


    <div class="container">


      <div class="  text-center">


        <div class="morlum  col-md-9  col-lg-6  col-xl-5   container">
          <div class="text-center   ">

            <a href="index.php" class="zoom navbar-brand "><img style="margin-top: -23px;" src="img/logo1.png"
                width="140" height="115"></a>
            <br>
            <br>
          </div>
          <h1 style="font-size:40px;   box-shadow: 0 1px 20px rgba(0,0,0,0.2);
border-radius: 15px;
padding: 10px;
color: white;
background: #007bff;
border: 2px solid  #086dda;
text-align: center;" class="text-center"><b> Agregar grados <i class="fas fa-clipboard-list ml-1"></i>
            </b></h1>
          <br>

        <div class="row">

            <div class="col-md-12">
              <div class=" from-label-group">
                <label style=" font-family:  'Titillium Web', sans-serif; font-size:20px;" class="text-center">
                  <i class="fas fa-mouse-pointer mr-1"></i>Seleccione los grados:</label>
                
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                        <input type="checkbox" aria-label="Checkbox for following text input" value="1" name='grados[]'>
                        </div>
                    </div>
                    <input type="text" class="form-control" aria-label="Text input with checkbox" readonly value="Primero">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                        <input type="checkbox" aria-label="Checkbox for following text input" value="2"  name='grados[]'>
                        </div>
                    </div>
                    <input type="text" class="form-control" aria-label="Text input with checkbox" readonly value="Segundo">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                        <input type="checkbox" aria-label="Checkbox for following text input" value="7"  name='grados[]'>
                        </div>
                    </div>
                    <input type="text" class="form-control" aria-label="Text input with checkbox" readonly value="Séptimo">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                        <input type="checkbox" aria-label="Checkbox for following text input" value="11"  name='grados[]'>
                        </div>
                    </div>
                    <input type="text" class="form-control" aria-label="Text input with checkbox" readonly value="Once">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                        <input type="checkbox" aria-label="Checkbox for following text input" value="mtds2"  name='grados[]'>
                        </div>
                    </div>
                    <input type="text" class="form-control" aria-label="Text input with checkbox" readonly value="Media técnica 11 Software">
                </div>
            </div>
        </div>




            <div class="container">






              <input style="font-size: 80%; 
           border-radius: 0.7rem;
             letter-spacing: .1rem;
             font-weight: bold;
             padding: 1rem;
             font-size: 23px;
             transition: all 0.2s; font-family:  'Titillium Web', sans-serif;"
                class=" btn btn-lg btn-primary btn-block  mb-2; " type="submit" value="Guardar">

              <p style="font-size: 20px; margin-top: -10px;" class="text-center">Volver a página principal</p>
              <li style="font-size: 50px;" class="list-inline-item"><a class="btn-block" style="color:#fff;" href="index.php"><i class="fas fa-arrow-circle-left"> </i></a></li>

           
              <div class="social mb-0 list-inline mt-1">
           
               
                <h2 class="text-center">Redes sociales</h2>
                <li class="list-inline-item "><a href="https://www.facebook.com/ayudameen.proyecayuda.3"
                    class="social-link"><i class="fa-2x fab fa-facebook-f"></i></a></li>
                <li class="list-inline-item"><a href="https://twitter.com/AYUDAMEEN1" class="social-link"><i
                      class="fab  fa-twitter"></i></a></li>
                <li class="list-inline-item"><a href="https://www.instagram.com/ayuda_me_en/" class="social-link"><i
                      class="fab fa-instagram"></i></a></li>


              </div>

            </div>
          </div>

        </div>

      </div>
    </div>

    </div>

  </form>




  <script src="js/jquery-3.4.1.slim.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>

</html>

<?php
    exit;
?>